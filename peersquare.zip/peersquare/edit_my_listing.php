<?php
session_start();
include 'db_connect.php';

if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = intval($_SESSION['user_id']);

if(!isset($_GET['id'])) {
    header('Location: marketplace.php');
    exit;
}

$id = intval($_GET['id']);

// fetch listing
$stmt = $conn->prepare("SELECT * FROM marketplace WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$item = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$item) {
    header('HTTP/1.1 404 Not Found');
    echo "Listing not found.";
    exit;
}

// ensure current user owns this listing
if(intval($item['user_id']) !== $user_id) {
    header('HTTP/1.1 403 Forbidden');
    echo "You don't have permission to edit this listing.";
    exit;
}

$err = $ok = "";

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $contact = trim($_POST['contact'] ?? '');

    // remove image option
    $remove_image = isset($_POST['remove_image']) && $_POST['remove_image'] === '1';
    $newImageName = null;

    // handle upload if provided
    if(isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
        if(in_array($_FILES['image']['type'], $allowed)) {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $newImageName = uniqid('p_') . '.' . $ext;
            $targetDir = __DIR__ . '/uploads/';
            if(!is_dir($targetDir)) mkdir($targetDir, 0755, true);
            if(!move_uploaded_file($_FILES['image']['tmp_name'], $targetDir . $newImageName)){
                $err = "Failed to upload new image.";
                $newImageName = null;
            }
        } else {
            $err = "Image type not allowed. Use JPG, PNG, WEBP or GIF.";
        }
    }

    if(!$err) {
        // Decide what status to set:
        $currentStatus = $item['status'] ?? 'pending';
        $newStatus = ($currentStatus === 'approved') ? 'approved' : 'pending';

        // Determine final image: remove/replace/keep
        $finalImage = $item['image'];
        if($remove_image) {
            if(!empty($finalImage) && file_exists(__DIR__ . '/uploads/' . $finalImage)) {
                @unlink(__DIR__ . '/uploads/' . $finalImage);
            }
            $finalImage = '';
        }
        if($newImageName) {
            if(!empty($item['image']) && file_exists(__DIR__ . '/uploads/' . $item['image'])) {
                @unlink(__DIR__ . '/uploads/' . $item['image']);
            }
            $finalImage = $newImageName;
        }

        // Update row including contact (types: s s d s s s i -> title,desc,price,image,contact,status,id)
        $stmt = $conn->prepare("UPDATE marketplace SET title=?, description=?, price=?, image=?, contact=?, status=? WHERE id=?");
        if(!$stmt){
            $err = "Failed to prepare update statement.";
        } else {
            $stmt->bind_param("ssdsssi", $title, $description, $price, $finalImage, $contact, $newStatus, $id);
            if($stmt->execute()) {
                $ok = "Listing updated.";
                $stmt->close();
                // refresh item data
                $stmt2 = $conn->prepare("SELECT * FROM marketplace WHERE id = ?");
                $stmt2->bind_param("i", $id);
                $stmt2->execute();
                $item = $stmt2->get_result()->fetch_assoc();
                $stmt2->close();
                header("Location: marketplace.php");
                exit;
            } else {
                $err = "Failed to update listing.";
                $stmt->close();
            }
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Listing</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    .preview-img { max-height: 220px; object-fit: cover; border-radius: 12px; }
  </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php"><img src="assets/images/P.png" alt="PeerSquare" style="height:45px;"></a>
    <div class="ms-auto">
      <a class="btn btn-outline-light btn-sm" href="marketplace.php">Marketplace</a>
      <a class="btn btn-danger btn-sm" href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <div class="card p-3 col-md-8 offset-md-2">
    <h4>Edit Listing</h4>

    <?php if($ok): ?><div class="alert alert-success"><?php echo htmlspecialchars($ok); ?></div><?php endif; ?>
    <?php if($err): ?><div class="alert alert-danger"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="mb-2">
        <label class="form-label">Title</label>
        <input class="form-control" name="title" required value="<?php echo htmlspecialchars($item['title']); ?>">
      </div>

      <div class="mb-2">
        <label class="form-label">Description</label>
        <textarea class="form-control" name="description" rows="4"><?php echo htmlspecialchars($item['description']); ?></textarea>
      </div>

      <div class="mb-2">
        <label class="form-label">Price (RM)</label>
        <input class="form-control" name="price" type="number" step="0.01" required value="<?php echo htmlspecialchars($item['price']); ?>">
      </div>

      <div class="mb-2">
        <label class="form-label">Contact (phone)</label>
        <input class="form-control" name="contact" type="text" placeholder="e.g., +60 12-345 6789" value="<?php echo htmlspecialchars($item['contact']); ?>">
      </div>

      <div class="mb-2">
        <label class="form-label">Current image</label><br>
        <?php if(!empty($item['image']) && file_exists(__DIR__ . '/uploads/' . $item['image'])): ?>
          <img src="uploads/<?php echo rawurlencode($item['image']); ?>" class="preview-img mb-2" alt="Current image"><br>
          <div class="form-check mb-2">
            <input class="form-check-input" type="checkbox" name="remove_image" value="1" id="removeImage">
            <label class="form-check-label" for="removeImage">Remove image</label>
          </div>
        <?php else: ?>
          <div class="mb-2 text-muted">No image uploaded</div>
        <?php endif; ?>
      </div>

      <div class="mb-3">
        <label class="form-label">Replace image (optional)</label>
        <input class="form-control" name="image" type="file" accept="image/*">
      </div>

      <div class="d-flex gap-2">
        <button class="btn btn-primary">Save changes</button>
        <a class="btn btn-outline-secondary" href="marketplace.php">Cancel</a>
      </div>
    </form>
  </div>
</div>

</body>
</html>