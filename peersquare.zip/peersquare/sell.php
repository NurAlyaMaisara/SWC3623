<?php
session_start();
include 'db_connect.php';
if(!isset($_SESSION['user_id'])){
  header("Location: login.php");
  exit;
}
$success = $error = "";
// preserve entered values on error
$title_val = $description_val = $contact_val = "";
$price_val = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $contact = trim($_POST['contact'] ?? '');
    $user_id = intval($_SESSION['user_id']);
    $imageName = null;

    // keep values for redisplay if error
    $title_val = $title;
    $description_val = $description;
    $price_val = $price;
    $contact_val = $contact;

    // Handle upload if any
    if(isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE){
        $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
        if(in_array($_FILES['image']['type'],$allowed)){
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $imageName = uniqid('p_').'.'.$ext;
            $uploadDir = __DIR__.'/uploads/';
            if(!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            if(!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir.$imageName)){
                $error = "Failed to upload image.";
                $imageName = null;
            }
        } else {
            $error = "Image type not allowed. Use JPG, PNG, WEBP or GIF.";
        }
    }

    if(!$error){
        if(is_null($imageName)) $imageName = "";
        // Insert including contact (types: title s, description s, price d, image s, user_id i, contact s)
        $stmt = $conn->prepare("INSERT INTO marketplace (title,description,price,image,user_id,contact) VALUES (?,?,?,?,?,?)");
        if(!$stmt){
            $error = "Database error (prepare failed).";
        } else {
            $stmt->bind_param("ssdsis", $title, $description, $price, $imageName, $user_id, $contact);
            if($stmt->execute()){
                $success = "Listing created and awaiting admin approval.";
                // clear form values
                $title_val = $description_val = "";
                $price_val = "";
                $contact_val = "";
            } else {
                $error = "Failed to post listing.";
            }
            $stmt->close();
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Sell an item | PeerSquare</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    .sell-card { max-width: 960px; margin: 0 auto; border-radius: 14px; overflow: hidden; }
    .upload-box { border: 1px dashed rgba(0,0,0,0.08); padding: 12px; border-radius: 12px; text-align: center; cursor: pointer; }
    .preview-img { width:100%; height:260px; object-fit:cover; border-radius:10px; display:block; }
  </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark">
  <div class="container d-flex justify-content-between align-items-center">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="assets/images/P.png" alt="PeerSquare" style="height:45px;">
    </a>
    <div class="d-flex align-items-center">
      <a href="marketplace.php" class="nav-link px-3 text-white">Marketplace</a>
      <a href="lostfound.php" class="nav-link px-3 text-white">Lost & Found</a>
      <a class="btn btn-danger btn-sm mx-1" href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-5 mb-5">
  <div class="card sell-card shadow-sm">
    <div class="row g-0">
      <div class="col-md-5 p-3 bg-white">
        <div id="uploadArea" class="upload-box" onclick="document.getElementById('imageInput').click();">
          <div id="previewWrap">
            <img id="preview" class="preview-img" src="" alt="Preview" style="display:none;">
            <div id="noPreview" class="hint">
              <div style="font-weight:700; color:var(--primary); font-size:1.1rem;">Upload a photo</div>
              <div class="mt-2">Drag & drop or click to select an image</div>
              <div class="mt-2 hint">Accepted: JPG, PNG, WEBP, GIF</div>
            </div>
          </div>
        </div>

        <div class="mt-3 d-flex gap-2">
          <input type="file" id="imageInput" name="image" accept="image/*" style="display:none;">
          <button id="chooseBtn" class="btn btn-outline-primary btn-sm" onclick="document.getElementById('imageInput').click(); return false;">Choose Image</button>
          <button id="removeBtn" class="btn btn-outline-secondary btn-sm" style="display:none;">Remove</button>
          <a class="btn btn-outline-secondary btn-sm ms-auto" href="marketplace.php">Back to Marketplace</a>
        </div>
      </div>

      <div class="col-md-7 p-4">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <h4 class="mb-0">Sell an item</h4>
          <div class="text-muted small">All listings are reviewed by admin</div>
        </div>

        <?php if($success): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <form id="sellForm" method="post" action="sell.php" enctype="multipart/form-data" novalidate>
          <div class="mb-3">
            <label class="form-label">Title</label>
            <input class="form-control" name="title" placeholder="E.g., MacBook Air 2020 (Good condition)" required value="<?php echo htmlspecialchars($title_val); ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea class="form-control" name="description" rows="5" placeholder="Provide details including condition, accessories, and contact (optional)"><?php echo htmlspecialchars($description_val); ?></textarea>
          </div>

          <div class="row g-2 mb-3">
            <div class="col-md-6">
              <label class="form-label">Price (RM)</label>
              <input class="form-control" name="price" type="number" step="0.01" required value="<?php echo htmlspecialchars($price_val); ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Contact (phone)</label>
              <input class="form-control" name="contact" type="text" placeholder="e.g., +60 12-345 6789" value="<?php echo htmlspecialchars($contact_val); ?>">
              <div class="hint mt-1">Phone number buyers can use to contact you.</div>
            </div>
          </div>

          <div class="d-flex gap-2">
            <button id="postBtn" class="btn btn-primary">Post for approval</button>
            <button id="resetBtn" type="button" class="btn btn-outline-secondary">Reset</button>
            <a class="btn btn-outline-secondary ms-auto" href="profile.php">My Profile</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  const input = document.getElementById('imageInput');
  const preview = document.getElementById('preview');
  const noPreview = document.getElementById('noPreview');
  const removeBtn = document.getElementById('removeBtn');
  const resetBtn = document.getElementById('resetBtn');
  const sellForm = document.getElementById('sellForm');

  input.addEventListener('change', function(e){
    const f = this.files && this.files[0];
    if(!f){
      preview.src = '';
      preview.style.display = 'none';
      noPreview.style.display = '';
      removeBtn.style.display = 'none';
      return;
    }
    const reader = new FileReader();
    reader.onload = function(ev){
      preview.src = ev.target.result;
      preview.style.display = 'block';
      noPreview.style.display = 'none';
      removeBtn.style.display = '';
    };
    reader.readAsDataURL(f);
  });

  removeBtn.addEventListener('click', function(e){
    e.preventDefault();
    input.value = '';
    preview.src = '';
    preview.style.display = 'none';
    noPreview.style.display = '';
    removeBtn.style.display = 'none';
  });

  resetBtn.addEventListener('click', function(){
    sellForm.reset();
    input.value = '';
    preview.src = '';
    preview.style.display = 'none';
    noPreview.style.display = '';
    removeBtn.style.display = 'none';
  });

  sellForm.addEventListener('submit', function(e){
    const title = sellForm.querySelector('[name=title]').value.trim();
    const price = sellForm.querySelector('[name=price]').value;
    if(!title){
      alert('Please enter a title for your listing.');
      e.preventDefault();
      return false;
    }
    if(!price || parseFloat(price) < 0){
      alert('Please enter a valid price.');
      e.preventDefault();
      return false;
    }
  });
})();
</script>
</body>
</html>