<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){
  header("Location: ../login.php");
  exit;
}
include '../db_connect.php';

if(!isset($_GET['id'])) {
  header("Location: manage_marketplace.php");
  exit;
}

$id = intval($_GET['id']);

// fetch the marketplace item
$stmt = $conn->prepare("SELECT * FROM marketplace WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$item = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$item) {
  header('HTTP/1.1 404 Not Found');
  echo "Listing not found.";
  exit;
}

$err = $ok = "";

if($_SERVER['REQUEST_METHOD'] === 'POST') {
  $title = trim($_POST['title'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $price = floatval($_POST['price'] ?? 0);
  $status = in_array($_POST['status'] ?? '', ['pending','approved','rejected']) ? $_POST['status'] : 'pending';
  $remove_image = isset($_POST['remove_image']) && $_POST['remove_image'] === '1';

  // handle new image upload (admin)
  $newImage = null;
  if(isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
    $allowed = ['image/jpeg','image/png','image/webp','image/gif'];
    if(!in_array($_FILES['image']['type'], $allowed)) {
      $err = "Image type not allowed. Use JPG, PNG, WEBP or GIF.";
    } elseif(!getimagesize($_FILES['image']['tmp_name'])) {
      $err = "Uploaded file is not a valid image.";
    } else {
      $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
      $newImage = uniqid('mkt_') . '.' . $ext;
      $targetDir = __DIR__ . '/../uploads/';
      if(!is_dir($targetDir)) mkdir($targetDir, 0755, true);
      if(!move_uploaded_file($_FILES['image']['tmp_name'], $targetDir . $newImage)) {
        $err = "Failed to upload image.";
        $newImage = null;
      }
    }
  }

  if(!$err) {
    // determine final image value
    $finalImage = $item['image'];
    if($remove_image) {
      if(!empty($finalImage) && file_exists(__DIR__ . '/../uploads/' . $finalImage)) {
        @unlink(__DIR__ . '/../uploads/' . $finalImage);
      }
      $finalImage = '';
    }
    if($newImage) {
      if(!empty($item['image']) && file_exists(__DIR__ . '/../uploads/' . $item['image'])) {
        @unlink(__DIR__ . '/../uploads/' . $item['image']);
      }
      $finalImage = $newImage;
    }

    // Correct bind_param types string: title(s), description(s), price(d), image(s), status(s), id(i)
    $upd = $conn->prepare("UPDATE marketplace SET title=?, description=?, price=?, image=?, status=? WHERE id=?");
    if(!$upd) {
      $err = "Failed to prepare update statement.";
    } else {
      $upd->bind_param("ssdssi", $title, $description, $price, $finalImage, $status, $id);
      if($upd->execute()) {
        $ok = "Listing updated successfully.";
        $upd->close();
        header("Location: manage_marketplace.php");
        exit;
      } else {
        $err = "Failed to update listing.";
        $upd->close();
      }
    }
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Marketplace Item</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/css/style.css" rel="stylesheet">
  <style>
    .preview-img { max-height:200px; object-fit:cover; border-radius:8px; display:block; width:100%; }
  </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="../index.php"><img src="../assets/images/P.png" alt="PeerSquare" style="height:40px;"></a>
    <div class="ms-auto">
      <a class="btn btn-outline-light btn-sm" href="manage_marketplace.php">Back</a>
      <a class="btn btn-danger btn-sm" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <div class="card p-3">
    <h4 class="mb-3">Edit Listing</h4>

    <?php if($ok): ?><div class="alert alert-success"><?php echo htmlspecialchars($ok); ?></div><?php endif; ?>
    <?php if($err): ?><div class="alert alert-danger"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="row g-2">
        <div class="col-md-8">
          <label class="form-label">Title</label>
          <input class="form-control" name="title" required value="<?php echo htmlspecialchars($item['title']); ?>">
        </div>
        <div class="col-md-4">
          <label class="form-label">Price (RM)</label>
          <input class="form-control" name="price" type="number" step="0.01" required value="<?php echo htmlspecialchars($item['price']); ?>">
        </div>
      </div>

      <div class="mt-2">
        <label class="form-label">Description</label>
        <textarea class="form-control" name="description" rows="4"><?php echo htmlspecialchars($item['description']); ?></textarea>
      </div>

      <div class="row g-2 mt-2">
        <div class="col-md-4">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <option value="pending" <?php if($item['status']=='pending') echo 'selected'; ?>>pending</option>
            <option value="approved" <?php if($item['status']=='approved') echo 'selected'; ?>>approved</option>
            <option value="rejected" <?php if($item['status']=='rejected') echo 'selected'; ?>>rejected</option>
          </select>
        </div>
        <div class="col-md-8">
          <label class="form-label">Seller ID</label>
          <input class="form-control" value="<?php echo intval($item['user_id']); ?>" disabled>
        </div>
      </div>

      <div class="mt-3">
        <label class="form-label">Current image</label>
        <div class="mb-2">
          <?php if(!empty($item['image']) && file_exists(__DIR__ . '/../uploads/' . $item['image'])): ?>
            <img src="../uploads/<?php echo rawurlencode($item['image']); ?>" class="preview-img" alt="Current image">
            <div class="form-check mt-2">
              <input class="form-check-input" type="checkbox" id="removeImage" name="remove_image" value="1">
              <label class="form-check-label" for="removeImage">Remove current image</label>
            </div>
          <?php else: ?>
            <div class="text-muted">No image uploaded</div>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label class="form-label">Replace / Upload image</label>
          <input class="form-control" type="file" name="image" accept="image/*">
          <div class="form-text">Accepted: JPG, PNG, WEBP, GIF</div>
        </div>
      </div>

      <div class="d-flex gap-2">
        <button class="btn btn-primary">Save changes</button>
        <a class="btn btn-outline-secondary" href="manage_marketplace.php">Cancel</a>
      </div>
    </form>
  </div>
</div>
</body>
</html>