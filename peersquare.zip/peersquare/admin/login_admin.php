<?php
session_start();
include '../db_connect.php';
$error='';
if($_SERVER['REQUEST_METHOD']=='POST'){
  $email = strtolower(trim($_POST['email']));
  $password = $_POST['password'];
  $stmt = $conn->prepare("SELECT id,password,role FROM users WHERE email=?");
  $stmt->bind_param("s",$email);
  $stmt->execute();
  $u = $stmt->get_result()->fetch_assoc();
  if($u && $u['role']=='admin' && password_verify($password,$u['password'])){
    $_SESSION['user_id'] = $u['id'];
    $_SESSION['role'] = 'admin';
    // set a short-lived admin cookie so public pages can show the Admin button without re-login
    // This cookie is for UI convenience only; session remains the source of truth.
    setcookie('is_admin', '1', 0, '/'); // expires at end of session
    header("Location: dashboard.php");
    exit;
  } else $error = "Invalid admin credentials.";
  $stmt->close();
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light">
<div class="container mt-5"><div class="col-md-4 offset-md-4 card p-3">
<h4>Admin Login</h4>
<?php if($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
<form method="post">
<input class="form-control mb-2" name="email" type="email" required>
<input class="form-control mb-2" name="password" type="password" required>
<button class="btn btn-warning w-100">Login</button>
</form>
</div></div></body></html>