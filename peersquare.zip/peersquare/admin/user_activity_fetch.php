<?php
// admin/user_activity_fetch.php
// Returns JSON with three arrays: listings, reports, orders for a given user_id
session_start();
include '../db_connect.php';
header('Content-Type: application/json; charset=utf-8');

if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'forbidden']);
    exit;
}

$userid = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
if($userid <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'invalid_user']);
    exit;
}

$result = ['listings' => [], 'reports' => [], 'orders' => []];

// Fetch marketplace listings (latest 20)
$stmt = $conn->prepare("SELECT id,title,price,status,created_at FROM marketplace WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->bind_param("i", $userid);
$stmt->execute();
$res = $stmt->get_result();
while($r = $res->fetch_assoc()){
    $result['listings'][] = [
        'id' => intval($r['id']),
        'title' => $r['title'],
        'price' => $r['price'],
        'status' => $r['status'],
        'created_at' => $r['created_at']
    ];
}
$stmt->close();

// Fetch lostfound reports (latest 20), excluding deleted
$stmt = $conn->prepare("SELECT id,item_name,category,status,created_at FROM lostfound WHERE user_id = ? AND status != 'deleted' ORDER BY created_at DESC LIMIT 20");
$stmt->bind_param("i", $userid);
$stmt->execute();
$res = $stmt->get_result();
while($r = $res->fetch_assoc()){
    $result['reports'][] = [
        'id' => intval($r['id']),
        'item_name' => $r['item_name'],
        'category' => $r['category'],
        'status' => $r['status'],
        'created_at' => $r['created_at']
    ];
}
$stmt->close();

// Fetch orders (latest 20)
$stmt = $conn->prepare("SELECT id,total_amount,status,payment_method,created_at FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->bind_param("i", $userid);
$stmt->execute();
$res = $stmt->get_result();
while($r = $res->fetch_assoc()){
    $result['orders'][] = [
        'id' => intval($r['id']),
        'total_amount' => $r['total_amount'],
        'status' => $r['status'],
        'payment_method' => $r['payment_method'],
        'created_at' => $r['created_at']
    ];
}
$stmt->close();

echo json_encode($result);
exit;