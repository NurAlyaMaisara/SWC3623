<?php
// admin/edit_lostfound.php
// Admin edit page for Lost & Found reports.
// Requires admin login.

session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){
  header("Location: ../login.php");
  exit;
}
include '../db_connect.php';

if(!isset($_GET['id']) || intval($_GET['id']) <= 0) {
  // If no id provided, redirect back
  header("Location: manage_lostfound.php");
  exit;
}
$id = intval($_GET['id']);

$err = $ok = "";

// Fetch existing report
$stmt = $conn->prepare("SELECT * FROM lostfound WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$report = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$report) {
  // Show a friendly message rather than a blank page
  http_response_code(404);
  echo "<!doctype html><html><body><h2>Report not found</h2><p>The requested lost &amp; found report was not found. It may have been deleted.</p><p><a href='manage_lostfound.php'>Back to reports</a></p></body></html>";
  exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Gather fields
  $item_name = trim($_POST['item_name'] ?? '');
  $category = trim($_POST['category'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $contact = trim($_POST['contact'] ?? '');
  $status = (isset($_POST['status']) && $_POST['status'] === 'found') ? 'found' : 'lost';
  $remove_image = isset($_POST['remove_image']) && $_POST['remove_image'] === '1';

  if($item_name === '') $err = "Item name is required.";

  // Handle image upload if provided
  $newImage = null;
  if(empty($err) && isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
    $allowedTypes = ['image/jpeg','image/png','image/gif','image/webp'];
    if(!in_array($_FILES['image']['type'], $allowedTypes)) {
      $err = "Image type not allowed. Use JPG, PNG, WEBP or GIF.";
    } elseif(!@getimagesize($_FILES['image']['tmp_name'])) {
      $err = "Uploaded file is not a valid image.";
    } else {
      $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
      $newImage = uniqid('lf_') . '.' . $ext;
      $uploadDir = __DIR__ . '/../uploads/';
      if(!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
      if(!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $newImage)) {
        $err = "Failed to upload new image.";
        $newImage = null;
      }
    }
  }

  if(!$err) {
    // Determine final image value
    $finalImage = $report['image'];
    if($remove_image) {
      if(!empty($finalImage) && file_exists(__DIR__ . '/../uploads/' . $finalImage)) {
        @unlink(__DIR__ . '/../uploads/' . $finalImage);
      }
      $finalImage = '';
    }
    if($newImage) {
      if(!empty($report['image']) && file_exists(__DIR__ . '/../uploads/' . $report['image'])) {
        @unlink(__DIR__ . '/../uploads/' . $report['image']);
      }
      $finalImage = $newImage;
    }

    // Update DB
    $u = $conn->prepare("UPDATE lostfound SET item_name=?, category=?, description=?, contact=?, status=?, image=? WHERE id=?");
    if(!$u) {
      $err = "Failed to prepare update statement.";
    } else {
      $u->bind_param("ssssssi", $item_name, $category, $description, $contact, $status, $finalImage, $id);
      if($u->execute()) {
        $ok = "Report updated.";
        $u->close();
        // Refresh the report variable and redirect back to manage list for admin UX
        header("Location: manage_lostfound.php");
        exit;
      } else {
        $err = "Failed to update report.";
        $u->close();
      }
    }
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Lost/Found Report — Admin</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background:#f7f7f8; padding-bottom:60px; }
    .container { max-width:820px; margin-top:28px; }
    .preview { max-height:260px; object-fit:cover; border-radius:8px; display:block; width:100%; }
  </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="dashboard.php">Admin</a>
    <div class="ms-auto">
      <a class="btn btn-outline-light btn-sm" href="manage_lostfound.php">Back to reports</a>
      <a class="btn btn-danger btn-sm" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container">
  <div class="card p-3">
    <h4>Edit Report</h4>
    <?php if($ok): ?><div class="alert alert-success"><?php echo htmlspecialchars($ok); ?></div><?php endif; ?>
    <?php if($err): ?><div class="alert alert-danger"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="row g-2">
        <div class="col-md-3">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <option value="lost" <?php if($report['status']=='lost') echo 'selected'; ?>>lost</option>
            <option value="found" <?php if($report['status']=='found') echo 'selected'; ?>>found</option>
          </select>
        </div>
        <div class="col-md-9">
          <label class="form-label">Item name</label>
          <input class="form-control" name="item_name" required value="<?php echo htmlspecialchars($report['item_name']); ?>">
        </div>
      </div>

      <div class="row g-2 mt-2">
        <div class="col-md-6">
          <label class="form-label">Category</label>
          <input class="form-control" name="category" value="<?php echo htmlspecialchars($report['category']); ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Contact</label>
          <input class="form-control" name="contact" value="<?php echo htmlspecialchars($report['contact']); ?>">
        </div>
      </div>

      <div class="mt-2">
        <label class="form-label">Description</label>
        <textarea class="form-control" name="description" rows="4"><?php echo htmlspecialchars($report['description']); ?></textarea>
      </div>

      <div class="mt-3">
        <label class="form-label">Current image</label>
        <div class="mb-2">
          <?php if(!empty($report['image']) && file_exists(__DIR__ . '/../uploads/' . $report['image'])): ?>
            <img src="../uploads/<?php echo rawurlencode($report['image']); ?>" class="preview" alt="Current image">
            <div class="form-check mt-2">
              <input class="form-check-input" type="checkbox" id="removeImage" name="remove_image" value="1">
              <label class="form-check-label" for="removeImage">Remove current image</label>
            </div>
          <?php else: ?>
            <div class="text-muted">No image uploaded</div>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label class="form-label">Replace / Upload image (optional)</label>
          <input class="form-control" type="file" name="image" accept="image/*">
          <div class="form-text">Accepted: JPG, PNG, WEBP, GIF</div>
        </div>
      </div>

      <div class="d-flex gap-2">
        <button class="btn btn-primary">Save changes</button>
        <a class="btn btn-outline-secondary" href="manage_lostfound.php">Cancel</a>
      </div>
    </form>
  </div>
</div>
</body>
</html>