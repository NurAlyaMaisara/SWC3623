<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){
  header("Location: ../login.php");
  exit;
}
include '../db_connect.php';

// gather stats
$totalUsers = $conn->query("SELECT COUNT(*) AS c FROM users")->fetch_assoc()['c'];
$totalListings = $conn->query("SELECT COUNT(*) AS c FROM marketplace")->fetch_assoc()['c'];
$totalPending = $conn->query("SELECT COUNT(*) AS c FROM marketplace WHERE status='pending'")->fetch_assoc()['c'];
$totalApproved = $conn->query("SELECT COUNT(*) AS c FROM marketplace WHERE status='approved'")->fetch_assoc()['c'];
$totalRejected = $conn->query("SELECT COUNT(*) AS c FROM marketplace WHERE status='rejected'")->fetch_assoc()['c'];
$totalReports = $conn->query("SELECT COUNT(*) AS c FROM lostfound")->fetch_assoc()['c'];

// recent items for quick actions
$recentPendingStmt = $conn->prepare("SELECT m.id, m.title, m.price, m.image, m.created_at, u.name, u.id as user_id FROM marketplace m LEFT JOIN users u ON m.user_id=u.id WHERE m.status='pending' ORDER BY m.created_at DESC LIMIT 6");
$recentPendingStmt->execute();
$recentPending = $recentPendingStmt->get_result();

$recentSalesStmt = $conn->prepare("SELECT o.id as order_id, o.total_amount, o.created_at, u.name, u.id as buyer_id FROM orders o LEFT JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC LIMIT 6");
$recentSalesStmt->execute();
$recentSales = $recentSalesStmt->get_result();

$recentUsersStmt = $conn->prepare("SELECT id,name,email,role,created_at FROM users ORDER BY created_at DESC LIMIT 6");
$recentUsersStmt->execute();
$recentUsers = $recentUsersStmt->get_result();

$recentReportsStmt = $conn->prepare("SELECT l.id, l.item_name, l.category, l.status, l.image, l.created_at, u.name FROM lostfound l LEFT JOIN users u ON l.user_id=u.id ORDER BY l.created_at DESC LIMIT 6");
$recentReportsStmt->execute();
$recentReports = $recentReportsStmt->get_result();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Dashboard - PeerSquare Marketplace</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="../assets/css/style.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background: #faf6f7; }
.admin-layout { display:grid; grid-template-columns: 250px 1fr; gap:30px; align-items:start; padding-top:18px; }
.admin-sidebar {position:sticky; top:86px; padding:16px; border-radius:14px; background:linear-gradient(180deg,rgba(255,255,255,.96),#fff); box-shadow:0 4px 16px rgba(0,0,0,0.04);}
.admin-sidebar .nav a {display:block; padding:10px 14px; margin-bottom:8px; border-radius:8px; color:#333; text-decoration:none;}
.admin-sidebar .nav a.active { background: #ffe4ec; border-left:4px solid #e54; padding-left:12px; }
.stat-grid {display:grid; grid-template-columns: repeat(5, 1fr); gap:14px;}
.stat-pill {padding:22px; border-radius:12px; background:linear-gradient(180deg,#fff,#f5f5fa);text-align:center;box-shadow:0 6px 18px rgba(0,0,0,.06);}
.stat-pill .small {font-size:1.06rem;color:#888;}
.recent-section .card {overflow:hidden;}
.thumb-small { width:90px; height:90px; object-fit:cover; border-radius:8px; margin-right:8px;}
.action-btn { width:100%; }
.card-title { font-size:1.10rem; font-weight:700; color:#d34; }
@media (max-width: 992px) { .admin-layout{grid-template-columns:1fr;} .stat-grid{grid-template-columns:repeat(2,1fr);} }
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="../index.php"><img src="../assets/images/P.png" alt="PeerSquare" style="height:42px;"></a>
    <div class="ms-auto">
      <a class="btn btn-outline-light btn-sm" href="../index.php">Shop</a>
      <a class="btn btn-danger btn-sm" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>
<div class="container mt-4">
  <div class="admin-layout">
    <!-- Sidebar -->
    <aside class="admin-sidebar">
      <h5 style="margin-bottom:6px;">Admin Center</h5>
      <nav class="nav mb-2">
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="manage_users.php">Manage Users</a>
        <a href="manage_marketplace.php">Manage Listings</a>
        <a href="manage_lostfound.php">Manage Lost/Found</a>
      </nav>
      <hr>
      <h6 class="small text-muted mb-2">Quick links</h6>
      <a class="btn btn-sm btn-outline-info w-100 mb-2" href="manage_marketplace.php?filter=pending">Pending Listings</a>
      <a class="btn btn-sm btn-outline-success w-100 mb-2" href="manage_marketplace.php?filter=approved">Approved Listings</a>
      <a class="btn btn-sm btn-outline-warning w-100 mb-2" href="manage_marketplace.php?filter=rejected">Rejected Listings</a>
      <a class="btn btn-sm btn-outline-secondary w-100" href="manage_lostfound.php">All Reports</a>
    </aside>

    <!-- Content -->
    <main class="admin-content">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0 text-danger" style="font-weight:800;">Admin Dashboard</h3>
        <div class="text-muted small">Welcome, admin</div>
      </div>

      <!-- Marketplace & User Stats -->
      <div class="stat-grid mb-4">
        <div class="stat-pill bg-white">
          <div class="small">All Users</div>
          <div style="font-size:24px;font-weight:900;"><?php echo intval($totalUsers); ?></div>
          <div><a class="btn btn-sm btn-outline-primary mt-1" href="manage_users.php">View all</a></div>
        </div>
        <div class="stat-pill bg-white">
          <div class="small">All Listings</div>
          <div style="font-size:24px;font-weight:900;"><?php echo intval($totalListings); ?></div>
          <div><a class="btn btn-sm btn-outline-primary mt-1" href="manage_marketplace.php">View all</a></div>
        </div>
        <div class="stat-pill bg-white">
          <div class="small">Pending</div>
          <div style="font-size:24px;font-weight:900;"><?php echo intval($totalPending); ?></div>
          <div><a class="btn btn-sm btn-outline-info mt-1" href="manage_marketplace.php?filter=pending">Review</a></div>
        </div>
        <div class="stat-pill bg-white">
          <div class="small">Approved</div>
          <div style="font-size:24px;font-weight:900;"><?php echo intval($totalApproved); ?></div>
          <div><a class="btn btn-sm btn-outline-success mt-1" href="manage_marketplace.php?filter=approved">Only approved</a></div>
        </div>
        <div class="stat-pill bg-white">
          <div class="small">Reports</div>
          <div style="font-size:24px;font-weight:900;"><?php echo intval($totalReports); ?></div>
          <div><a class="btn btn-sm btn-outline-secondary mt-1" href="manage_lostfound.php">All reports</a></div>
        </div>
      </div>

      <!-- Actions / Recent Activity -->
      <div class="row g-3">
        <!-- Recent Pending Listings -->
        <div class="col-md-6">
          <div class="card p-3 recent-section">
            <h5 class="card-title">Pending Listings</h5>
            <?php if($recentPending->num_rows == 0): ?>
              <div class="alert alert-info">No pending listings.</div>
            <?php else: ?>
              <div class="list-group">
                <?php while($row = $recentPending->fetch_assoc()): ?>
                  <div class="list-group-item d-flex align-items-center">
                    <?php if(!empty($row['image']) && file_exists(__DIR__ . "/../uploads/".$row['image'])): ?>
                      <img src="../uploads/<?php echo rawurlencode($row['image']); ?>" class="thumb-small" alt="">
                    <?php else: ?>
                      <div class="thumb-small" style="background:#fff7f8;display:flex;align-items:center;justify-content:center;color:#c44;font-weight:700;">No image</div>
                    <?php endif; ?>
                    <div style="flex:1;">
                      <div class="fw-bold"><?php echo htmlspecialchars($row['title']); ?> <span class="text-muted small">RM <?php echo number_format($row['price'],2); ?></span></div>
                      <div class="small text-muted">By <a href="edit_user.php?id=<?php echo intval($row['user_id']); ?>" class="link-primary"><?php echo htmlspecialchars($row['name'] ?: 'Unknown'); ?></a>, <?php echo htmlspecialchars(date('M j, Y', strtotime($row['created_at']))); ?></div>
                      <div class="mt-1 d-flex gap-2">
                        <form method="post" action="manage_marketplace.php" style="display:inline;" onsubmit="return confirm('Approve this listing?');">
                          <input type="hidden" name="id" value="<?php echo intval($row['id']); ?>">
                          <button name="action" value="approve" class="btn btn-success btn-sm">Approve</button>
                        </form>
                        <form method="post" action="manage_marketplace.php" style="display:inline;" onsubmit="return confirm('Reject this listing?');">
                          <input type="hidden" name="id" value="<?php echo intval($row['id']); ?>">
                          <button name="action" value="reject" class="btn btn-warning btn-sm">Reject</button>
                        </form>
                        <form method="post" action="manage_marketplace.php" style="display:inline;" onsubmit="return confirm('Delete this listing?');">
                          <input type="hidden" name="id" value="<?php echo intval($row['id']); ?>">
                          <button name="action" value="delete" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                      </div>
                    </div>
                  </div>
                <?php endwhile; ?>
              </div>
              <div class="mt-2 text-end">
                <a href="manage_marketplace.php?filter=pending" class="btn btn-sm btn-outline-primary">View all pending</a>
              </div>
            <?php endif; ?>
          </div>
        </div>
        <!-- Recent Sales -->
        <div class="col-md-6">
          <div class="card p-3 recent-section">
            <h5 class="card-title">Recent Sales</h5>
            <?php if($recentSales->num_rows == 0): ?>
              <div class="alert alert-info">No recent sales.</div>
            <?php else: ?>
              <div class="list-group">
                <?php while($sale = $recentSales->fetch_assoc()): ?>
                  <div class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                      <div class="fw-bold">Order #<?php echo intval($sale['order_id']); ?> · <span class="text-success">RM <?php echo number_format($sale['total_amount'],2); ?></span></div>
                      <div class="small text-muted">By <a href="edit_user.php?id=<?php echo intval($sale['buyer_id']); ?>" class="link-primary"><?php echo htmlspecialchars($sale['name']); ?></a>, <?php echo htmlspecialchars(date('M j, Y', strtotime($sale['created_at']))); ?></div>
                    </div>
                  </div>
                <?php endwhile; ?>
              </div>
              <div class="mt-2 text-end">
                <a href="admin_orders.php" class="btn btn-sm btn-outline-primary">View all orders</a>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="row g-3 mt-2">
        <!-- Recent Reports -->
        <div class="col-md-6">
          <div class="card p-3 recent-section">
            <h5 class="card-title">Recent Lost/Found Reports</h5>
            <?php if($recentReports->num_rows == 0): ?>
              <div class="alert alert-info">No recent reports.</div>
            <?php else: ?>
              <div class="list-group">
                <?php while($r = $recentReports->fetch_assoc()): ?>
                  <div class="list-group-item d-flex align-items-center">
                    <?php if(!empty($r['image']) && file_exists(__DIR__ . "/../uploads/".$r['image'])): ?>
                      <img src="../uploads/<?php echo rawurlencode($r['image']); ?>" class="thumb-small" alt="">
                    <?php else: ?>
                      <div class="thumb-small" style="background:#fff7f8;display:flex;align-items:center;justify-content:center;color:#c44;font-weight:700;">No image</div>
                    <?php endif; ?>
                    <div style="flex:1;">
                      <div class="fw-bold"><?php echo htmlspecialchars($r['item_name']); ?> <span class="badge bg-info text-dark"><?php echo htmlspecialchars($r['category']); ?></span></div>
                      <div class="small text-muted"><?php echo htmlspecialchars(ucfirst($r['status'])); ?>, <?php echo htmlspecialchars($r['name'] ?: 'Unknown'); ?> — <?php echo htmlspecialchars(date('M j, Y', strtotime($r['created_at']))); ?></div>
                      <div class="mt-1 d-flex gap-2">
                        <a class="btn btn-outline-primary btn-sm" href="edit_lostfound.php?id=<?php echo intval($r['id']); ?>">Edit</a>
                        <form method="post" action="manage_lostfound.php" style="display:inline;" onsubmit="return confirm('Delete this report?');">
                          <input type="hidden" name="delete_id" value="<?php echo intval($r['id']); ?>">
                          <button class="btn btn-danger btn-sm">Delete</button>
                        </form>
                        <?php if($r['status']!='resolved'): ?>
                        <form method="post" action="manage_lostfound.php" style="display:inline;" onsubmit="return confirm('Mark as resolved?');">
                          <input type="hidden" name="mark_resolved" value="<?php echo intval($r['id']); ?>">
                          <button class="btn btn-success btn-sm">Mark Resolved</button>
                        </form>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                <?php endwhile; ?>
              </div>
              <div class="mt-2 text-end">
                <a href="manage_lostfound.php" class="btn btn-sm btn-outline-primary">View all reports</a>
              </div>
            <?php endif; ?>
          </div>
        </div>
        <!-- Recent Users -->
        <div class="col-md-6">
          <div class="card p-3">
            <h5 class="card-title">Recent Users</h5>
            <?php if($recentUsers->num_rows == 0): ?>
              <div class="alert alert-info">No recent users.</div>
            <?php else: ?>
              <div class="list-group">
                <?php while($u = $recentUsers->fetch_assoc()): ?>
                  <div class="list-group-item">
                    <div class="fw-bold"><a href="edit_user.php?id=<?php echo intval($u['id']); ?>" class="link-primary"><?php echo htmlspecialchars($u['name']); ?></a></div>
                    <div class="small text-muted"><?php echo htmlspecialchars($u['email']); ?> · Role: <strong><?php echo htmlspecialchars($u['role']); ?></strong></div>
                    <div class="small text-muted mb-1">Joined: <?php echo htmlspecialchars(date('M j, Y', strtotime($u['created_at']))); ?></div>
                    <div class="d-flex gap-2">
                      <a class="btn btn-outline-secondary btn-sm" href="edit_user.php?id=<?php echo intval($u['id']); ?>">Edit</a>
                      <form method="post" action="manage_users.php" style="display:inline;" onsubmit="return confirm('Delete user?');">
                        <input type="hidden" name="delete_id" value="<?php echo intval($u['id']); ?>">
                        <button class="btn btn-danger btn-sm">Delete</button>
                      </form>
                    </div>
                  </div>
                <?php endwhile; ?>
              </div>
              <div class="mt-2 text-end">
                <a href="manage_users.php" class="btn btn-sm btn-outline-primary">All users</a>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>