<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='admin'){ header("Location: ../login.php"); exit; }
include '../db_connect.php';

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$msg = '';

// Handle POST actions: change role or delete
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    // change role
    if(isset($_POST['change_role'], $_POST['user_id'], $_POST['role'])){
        $uid = intval($_POST['user_id']);
        $newrole = $_POST['role'] === 'admin' ? 'admin' : 'user';
        if($uid === intval($_SESSION['user_id']) && $newrole !== 'admin'){
            $msg = "You cannot remove your own admin role.";
        } else {
            $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
            $stmt->bind_param("si", $newrole, $uid);
            $stmt->execute();
            $stmt->close();
            header("Location: manage_users.php?q=" . urlencode($search));
            exit;
        }
    }

    // delete user (full delete with all associated info and files)
    if(isset($_POST['delete_id'])){
        $did = intval($_POST['delete_id']);
        if($did == $_SESSION['user_id']){
            $msg = "You cannot delete your own account while logged in.";
        } else {
            // 1. Delete marketplace images posted by user
            $mq = $conn->prepare("SELECT image FROM marketplace WHERE user_id = ?");
            $mq->bind_param("i", $did);
            $mq->execute();
            $mqRes = $mq->get_result();
            while($r = $mqRes->fetch_assoc()){
                if(!empty($r['image'])) {
                    $file = __DIR__ . '/../uploads/' . $r['image'];
                    if(file_exists($file)) @unlink($file);
                }
            }
            $mq->close();

            // 2. Delete lostfound images posted by user
            $lq = $conn->prepare("SELECT image FROM lostfound WHERE user_id = ?");
            $lq->bind_param("i", $did);
            $lq->execute();
            $lqRes = $lq->get_result();
            while($r = $lqRes->fetch_assoc()){
                if(!empty($r['image'])) {
                    $file = __DIR__ . '/../uploads/' . $r['image'];
                    if(file_exists($file)) @unlink($file);
                }
            }
            $lq->close();

            // 3. Delete user's marketplace listings
            $d1 = $conn->prepare("DELETE FROM marketplace WHERE user_id = ?");
            $d1->bind_param("i", $did);
            $d1->execute();
            $d1->close();

            // 4. Delete user's lostfound reports
            $d2 = $conn->prepare("DELETE FROM lostfound WHERE user_id = ?");
            $d2->bind_param("i", $did);
            $d2->execute();
            $d2->close();

            // 5. Delete user's orders
            $d3 = $conn->prepare("DELETE FROM orders WHERE user_id = ?");
            $d3->bind_param("i", $did);
            $d3->execute();
            $d3->close();

            // 6. Delete user's cart items if cart_items table exists
            if ($conn->query("SHOW TABLES LIKE 'cart_items'")->num_rows) {
                $dCart = $conn->prepare("DELETE FROM cart_items WHERE user_id = ?");
                $dCart->bind_param("i", $did);
                $dCart->execute();
                $dCart->close();
            }

            // 7. Optionally: delete contact_messages (if exists)
            if ($conn->query("SHOW TABLES LIKE 'contact_messages'")->num_rows) {
                $dContact = $conn->prepare("DELETE FROM contact_messages WHERE user_id = ?");
                $dContact->bind_param("i", $did);
                $dContact->execute();
                $dContact->close();
            }

            // 8. Delete user record itself
            $dUser = $conn->prepare("DELETE FROM users WHERE id = ?");
            $dUser->bind_param("i", $did);
            $dUser->execute();
            $dUser->close();

            header("Location: manage_users.php?q=" . urlencode($search));
            exit;
        }
    }
}

// Fetch users (with search)
if($search !== ''){
    $like = '%' . $search . '%';
    $stmt = $conn->prepare("SELECT id,name,email,role,created_at FROM users WHERE name LIKE ? OR email LIKE ? ORDER BY created_at DESC");
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();
    $res = $stmt->get_result();
} else {
    $res = $conn->query("SELECT id,name,email,role,created_at FROM users ORDER BY created_at DESC");
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Manage Users</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="../assets/css/style.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
.admin-layout { display:grid; grid-template-columns: 220px 1fr; gap:20px; padding-top:18px; }
.admin-sidebar { position:sticky; top:86px; padding:14px; border-radius:12px; background:linear-gradient(180deg, rgba(255,255,255,0.95), rgba(255,255,255,0.9)); box-shadow: 0 6px 18px rgba(0,0,0,0.04); }
.manage-grid { display:grid; grid-template-columns: repeat(auto-fill,minmax(280px,1fr)); gap:14px; }
.card .card-body { padding:12px; }
.small-muted { color:#777; font-size:0.9rem; }
@media (max-width:992px){ .admin-layout { grid-template-columns: 1fr; } }
</style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark">
  <div class="container d-flex justify-content-between align-items-center">
    <a class="navbar-brand" href="../index.php"><img src="../assets/images/P.png" alt="PeerSquare" style="height:42px;"></a>
    <div class="d-flex gap-2">
      <a class="btn btn-outline-light btn-sm" href="../index.php">Site</a>
      <a class="btn btn-danger btn-sm" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <div class="admin-layout">
    <?php include 'sidebar.php'; ?>

    <main>
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0">Manage Users</h3>
        <form method="get" class="d-flex" style="max-width:420px;">
          <input name="q" class="form-control me-2" placeholder="Search by name or email" value="<?php echo htmlspecialchars($search); ?>">
          <button class="btn btn-primary">Search</button>
        </form>
      </div>

      <?php if($msg): ?><div class="alert alert-warning"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

      <div class="manage-grid">
        <?php while($u = $res->fetch_assoc()): ?>
          <div class="card">
            <div class="card-body">
              <h5 class="card-title mb-1"><?php echo htmlspecialchars($u['name']); ?></h5>
              <div class="small-muted mb-2"><?php echo htmlspecialchars($u['email']); ?></div>
              <div class="small-muted mb-2">Role: <strong><?php echo htmlspecialchars($u['role']); ?></strong></div>

              <div class="d-grid gap-2">
                <a class="btn btn-outline-primary btn-sm" href="edit_user.php?id=<?php echo intval($u['id']); ?>">Edit</a>

                <form method="post" onsubmit="return confirm('Delete user?');" style="display:inline;">
                  <input type="hidden" name="delete_id" value="<?php echo intval($u['id']); ?>">
                  <?php if(intval($u['id']) !== intval($_SESSION['user_id'])): ?>
                    <button class="btn btn-danger btn-sm">Delete</button>
                  <?php else: ?>
                    <button class="btn btn-danger btn-sm" disabled>Delete</button>
                  <?php endif; ?>
                </form>

                <form method="post" class="d-flex gap-2" onsubmit="return true;">
                  <input type="hidden" name="user_id" value="<?php echo intval($u['id']); ?>">
                  <select name="role" class="form-select form-select-sm">
                    <option value="user" <?php if($u['role']=='user') echo 'selected'; ?>>user</option>
                    <option value="admin" <?php if($u['role']=='admin') echo 'selected'; ?>>admin</option>
                  </select>
                  <button name="change_role" class="btn btn-outline-secondary btn-sm">Change</button>
                </form>

                <!-- New: View activity button -->
                <button class="btn btn-outline-info btn-sm mt-2 view-activity-btn" data-user-id="<?php echo intval($u['id']); ?>" data-user-name="<?php echo htmlspecialchars($u['name']); ?>">View activity</button>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
      </div>

    </main>
  </div>
</div>

<!-- Activity Modal -->
<div class="modal fade" id="userActivityModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">User activity — <span id="uamUserName"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="uamLoading" class="text-center py-4">Loading…</div>
        <div id="uamContent" style="display:none;">
          <h6>Marketplace listings</h6>
          <div id="uamListings" class="mb-3"></div>

          <h6>Lost & Found reports</h6>
          <div id="uamReports" class="mb-3"></div>

          <h6>Orders</h6>
          <div id="uamOrders" class="mb-3"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button id="uamClose" type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
  function el(sel){ return document.querySelector(sel); }
  function elAll(sel){ return Array.from(document.querySelectorAll(sel)); }

  elAll('.view-activity-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      var uid = this.getAttribute('data-user-id');
      var uname = this.getAttribute('data-user-name') || 'User';
      el('#uamUserName').textContent = uname;
      el('#uamLoading').style.display = '';
      el('#uamContent').style.display = 'none';
      // clear previous content
      el('#uamListings').innerHTML = '';
      el('#uamReports').innerHTML = '';
      el('#uamOrders').innerHTML = '';

      // Show modal
      var modal = new bootstrap.Modal(document.getElementById('userActivityModal'));
      modal.show();

      // Fetch activity with credentials included and better error handling
      fetch('user_activity_fetch.php?user_id=' + encodeURIComponent(uid), {
        method: 'GET',
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' }
      })
        .then(function(res){
          if(!res.ok){
            // try to read body text to show server error message
            return res.text().then(function(txt){
              throw { status: res.status, text: txt || ('HTTP ' + res.status) };
            });
          }
          // If server returned JSON, parse it
          return res.text().then(function(body){
            try {
              return JSON.parse(body);
            } catch (err) {
              // Not JSON — show text to admin for debugging
              throw { status: res.status, text: body || 'Invalid JSON response' };
            }
          });
        })
        .then(function(json){
          el('#uamLoading').style.display = 'none';
          el('#uamContent').style.display = '';

          // If server returned an error field, show it
          if(json && json.error){
            el('#uamListings').innerHTML = '<div class="text-danger">Error: ' + escapeHtml(json.error) + '</div>';
            el('#uamReports').innerHTML = '';
            el('#uamOrders').innerHTML = '';
            return;
          }

          // Listings
          var listings = json.listings || [];
          if(listings.length === 0) {
            el('#uamListings').innerHTML = '<div class="small text-muted">No listings</div>';
          } else {
            var out = '<div class="list-group">';
            listings.forEach(function(l){
              out += '<div class="list-group-item d-flex justify-content-between align-items-start">';
              out += '<div>';
              out += '<div style="font-weight:700;">' + (l.title ? escapeHtml(l.title) : '') + '</div>';
              out += '<div class="small text-muted">RM ' + (parseFloat(l.price||0).toFixed(2)) + ' · ' + (l.status||'') + ' · ' + (l.created_at||'') + '</div>';
              out += '</div>';
              out += '<div><a class="btn btn-sm btn-outline-primary" href="../marketplace.php?q=' + encodeURIComponent(l.title||'') + '">View</a></div>';
              out += '</div>';
            });
            out += '</div>';
            el('#uamListings').innerHTML = out;
          }

          // Reports
          var reports = json.reports || [];
          if(reports.length === 0) {
            el('#uamReports').innerHTML = '<div class="small text-muted">No reports</div>';
          } else {
            var out = '<div class="list-group">';
            reports.forEach(function(r){
              out += '<div class="list-group-item d-flex justify-content-between align-items-start">';
              out += '<div>';
              out += '<div style="font-weight:700;">' + (r.item_name ? escapeHtml(r.item_name) : '') + '</div>';
              out += '<div class="small text-muted">' + (r.category||'') + ' · ' + (r.status||'') + ' · ' + (r.created_at||'') + '</div>';
              out += '</div>';
              out += '<div><a class="btn btn-sm btn-outline-primary" href="../lostfound.php?q=' + encodeURIComponent(r.item_name||'') + '">View</a></div>';
              out += '</div>';
            });
            out += '</div>';
            el('#uamReports').innerHTML = out;
          }

          // Orders
          var orders = json.orders || [];
          if(orders.length === 0) {
            el('#uamOrders').innerHTML = '<div class="small text-muted">No orders</div>';
          } else {
            var out = '<div class="list-group">';
            orders.forEach(function(o){
              out += '<div class="list-group-item d-flex justify-content-between align-items-start">';
              out += '<div>';
              out += '<div style="font-weight:700;">Order #' + (o.id || '') + ' — RM ' + (parseFloat(o.total_amount||0).toFixed(2)) + '</div>';
              out += '<div class="small text-muted">' + (o.status||'') + ' · ' + (o.payment_method||'') + ' · ' + (o.created_at||'') + '</div>';
              out += '</div>';
              out += '<div><a class="btn btn-sm btn-outline-primary" href="../admin/admin_orders.php?q=' + encodeURIComponent(o.id||'') + '">View</a></div>';
              out += '</div>';
            });
            out += '</div>';
            el('#uamOrders').innerHTML = out;
          }
        })
        .catch(function(err){
          // Show useful debug information in the modal
          el('#uamLoading').style.display = 'none';
          el('#uamContent').style.display = '';
          var msg = 'Failed to load activity';
          if(err && err.text) msg += ': ' + err.text;
          else if(err && err.status) msg += ' (HTTP ' + err.status + ')';
          el('#uamListings').innerHTML = '<div class="text-danger small">' + escapeHtml(msg) + '</div>';
          el('#uamReports').innerHTML = '';
          el('#uamOrders').innerHTML = '';
          console.error('user_activity_fetch error:', err);
        });
    });
  });

  function escapeHtml(s) {
    if(!s) return '';
    return s.replace(/[&<>"']/g, function(m){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[m]; });
  }
})();
</script>
</body>
</html>