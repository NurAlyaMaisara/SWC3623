<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='admin'){ header("Location: ../login.php"); exit; }
include '../db_connect.php';

if(!isset($_GET['id'])) { header("Location: manage_users.php"); exit; }
$uid = intval($_GET['id']);
$msg = "";

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $name = trim($_POST['name']);
  $email = strtolower(trim($_POST['email']));
  $role = $_POST['role'];
  $newpass = $_POST['new_password'];

  if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $msg = "Invalid email.";
  } elseif($uid === intval($_SESSION['user_id']) && $role !== 'admin') {
    $msg = "You cannot remove your own admin role.";
  } else {
    if($newpass !== "") {
      if(strlen($newpass) < 6) $msg = "Password too short.";
      else {
        $hash = password_hash($newpass, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET name=?, email=?, role=?, password=? WHERE id=?");
        $stmt->bind_param("ssssi",$name,$email,$role,$hash,$uid);
      }
    } else {
      $stmt = $conn->prepare("UPDATE users SET name=?, email=?, role=? WHERE id=?");
      $stmt->bind_param("sssi",$name,$email,$role,$uid);
    }
    if(empty($msg)){
      if($stmt->execute()){
        $msg = "User updated.";
        $stmt->close();
        header("Location: manage_users.php"); exit;
      } else {
        $msg = "Failed to update user. Email may already be used.";
      }
    }
  }
}

// fetch user
$stmt = $conn->prepare("SELECT id,name,email,role FROM users WHERE id=?");
$stmt->bind_param("i",$uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
if(!$user) { header("Location: manage_users.php"); exit; }
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Edit User</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light">
<div class="container mt-4">
  <div class="card col-md-6 offset-md-3 p-3">
    <h4>Edit User</h4>
    <?php if($msg): ?><div class="alert alert-info"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <form method="post">
      <div class="mb-2">
        <label class="form-label">Name</label>
        <input class="form-control" name="name" required value="<?php echo htmlspecialchars($user['name']); ?>">
      </div>
      <div class="mb-2">
        <label class="form-label">Email</label>
        <input class="form-control" name="email" type="email" required value="<?php echo htmlspecialchars($user['email']); ?>">
      </div>
      <div class="mb-2">
        <label class="form-label">Role</label>
        <select name="role" class="form-select">
          <option <?php if($user['role']=='user') echo 'selected'; ?> value="user">user</option>
          <option <?php if($user['role']=='admin') echo 'selected'; ?> value="admin">admin</option>
        </select>
      </div>
      <div class="mb-2">
        <label class="form-label">Reset password (leave blank to keep)</label>
        <input class="form-control" name="new_password" type="password">
      </div>
      <div class="d-flex gap-2">
        <button class="btn btn-primary">Save</button>
        <a class="btn btn-outline-secondary" href="manage_users.php">Cancel</a>
      </div>
    </form>
  </div>
</div>
</body></html>