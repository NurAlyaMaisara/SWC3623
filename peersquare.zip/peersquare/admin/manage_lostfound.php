<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='admin'){ header("Location: ../login.php"); exit; }
include '../db_connect.php';

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$msg = '';

// Handle delete and resolve (soft-delete now)
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    if(isset($_POST['delete_id'])){
        $id = intval($_POST['delete_id']);
        $stmt = $conn->prepare("UPDATE lostfound SET status='deleted' WHERE id=?");
        $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
        header("Location: manage_lostfound.php?q=" . urlencode($search));
        exit;
    }
    if(isset($_POST['mark_resolved'])){
        $id = intval($_POST['mark_resolved']);
        $stmt = $conn->prepare("UPDATE lostfound SET status='resolved' WHERE id=?");
        $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
        header("Location: manage_lostfound.php?q=" . urlencode($search));
        exit;
    }
}

// Fetch records with optional search
if($search !== ''){
    $like = '%' . $search . '%';
    $stmt = $conn->prepare("SELECT l.*, u.name FROM lostfound l LEFT JOIN users u ON l.user_id=u.id WHERE (l.item_name LIKE ? OR l.description LIKE ? OR l.category LIKE ?) ORDER BY l.created_at DESC");
    $stmt->bind_param("sss",$like,$like,$like); $stmt->execute(); $res = $stmt->get_result();
} else {
    $res = $conn->query("SELECT l.*, u.name FROM lostfound l LEFT JOIN users u ON l.user_id=u.id ORDER BY l.created_at DESC");
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Manage Lost/Found</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="../assets/css/style.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
.admin-layout { display:grid; grid-template-columns: 220px 1fr; gap:20px; padding-top:18px; }
.grid { display:grid; grid-template-columns: repeat(auto-fill,minmax(300px,1fr)); gap:14px; }
.thumb { width:100%; height:160px; object-fit:cover; border-radius:10px; }
@media (max-width:992px){ .admin-layout { grid-template-columns: 1fr; } }
</style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="../index.php"><img src="../assets/images/P.png" alt="PeerSquare" style="height:42px;"></a>
    <div class="ms-auto">
      <a class="btn btn-outline-light btn-sm" href="../index.php">Site</a>
      <a class="btn btn-danger btn-sm" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <div class="admin-layout">
    <?php include 'sidebar.php'; ?>

    <main>
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0">Lost &amp; Found Reports</h3>
        <a class="btn btn-outline-primary btn-sm" href="manage_lostfound.php">Refresh</a>
      </div>

      <div class="grid">
        <?php while($r = $res->fetch_assoc()): ?>
          <div class="card">
            <?php if(!empty($r['image']) && file_exists(__DIR__ . "/../uploads/".$r['image'])): ?>
              <img src="../uploads/<?php echo rawurlencode($r['image']); ?>" class="thumb" alt="">
            <?php else: ?>
              <div class="thumb" style="display:flex;align-items:center;justify-content:center;background:#fff7f8;color:#c44;font-weight:700;">No image</div>
            <?php endif; ?>
            <div class="card-body">
              <h5><?php echo htmlspecialchars($r['item_name']); ?></h5>
              <div class="small text-muted mb-1"><?php echo htmlspecialchars($r['category']); ?> &middot; <?php echo htmlspecialchars(ucfirst($r['status'])); ?></div>
              <div class="small text-muted mb-2">By <?php echo htmlspecialchars($r['name'] ?: 'Unknown'); ?> — <?php echo htmlspecialchars(date('M j, Y', strtotime($r['created_at']))); ?></div>
              <p class="small text-muted mb-2"><?php echo nl2br(htmlspecialchars(strlen($r['description'])>150?substr($r['description'],0,150).'...':$r['description'])); ?></p>

              <div class="d-flex gap-2">
                <a class="btn btn-outline-primary btn-sm" href="edit_lostfound.php?id=<?php echo intval($r['id']); ?>">Edit</a>

                <form method="post" onsubmit="return confirm('Delete this report?');">
                  <input type="hidden" name="delete_id" value="<?php echo intval($r['id']); ?>">
                  <button class="btn btn-danger btn-sm">Delete</button>
                </form>

                <?php if($r['status'] !== 'resolved'): ?>
                <form method="post" onsubmit="return confirm('Mark this report resolved?');">
                  <input type="hidden" name="mark_resolved" value="<?php echo intval($r['id']); ?>">
                  <button class="btn btn-success btn-sm">Mark Resolved</button>
                </form>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
      </div>

    </main>
  </div>
</div>
</body>
</html>