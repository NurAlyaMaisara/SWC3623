<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='admin'){ header("Location: ../login.php"); exit; }
include '../db_connect.php';

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$filter = isset($_GET['filter']) ? trim($_GET['filter']) : '';
$msg = '';

// Handle post actions (approve/reject/delete)
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['id'])){
    $id = intval($_POST['id']);
    $action = $_POST['action'];
    if($action === 'approve'){
        $stmt = $conn->prepare("UPDATE marketplace SET status='approved' WHERE id=?");
        $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
    } elseif($action === 'reject'){
        $stmt = $conn->prepare("UPDATE marketplace SET status='rejected' WHERE id=?");
        $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
    } elseif($action === 'delete'){
        $img = $conn->query("SELECT image FROM marketplace WHERE id=$id")->fetch_assoc()['image'];
        if($img && file_exists(__DIR__ . "/../uploads/".$img)) @unlink(__DIR__ . "/../uploads/".$img);
        $stmt = $conn->prepare("DELETE FROM marketplace WHERE id=?");
        $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
    }
    header("Location: manage_marketplace.php?q=".urlencode($search)."&filter=".urlencode($filter));
    exit;
}

// Fetch listings with search/filter
$where = "WHERE 1=1";
$params = [];
$types = '';
if($filter !== '') {
    $where .= " AND m.status = ?";
    $types .= 's';
    $params[] = $filter;
}
if($search !== '') {
    $where .= " AND (m.title LIKE ? OR m.description LIKE ?)";
    $types .= 'ss';
    $like = '%' . $search . '%';
    $params[] = $like;
    $params[] = $like;
}

$sql = "SELECT m.*, u.name FROM marketplace m LEFT JOIN users u ON m.user_id=u.id $where ORDER BY m.created_at DESC";
if($types){
    $stmt = $conn->prepare($sql);
    $bind_names[] = $types;
    for ($i=0; $i<count($params); $i++) {
        $bind_name = 'bind' . $i;
        $$bind_name = $params[$i];
        $bind_names[] = &$$bind_name;
    }
    call_user_func_array(array($stmt,'bind_param'), $bind_names);
    $stmt->execute();
    $res = $stmt->get_result();
} else {
    $res = $conn->query($sql);
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Manage Marketplace</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="../assets/css/style.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
.admin-layout { display:grid; grid-template-columns: 220px 1fr; gap:20px; padding-top:18px; }
.card .card-body { padding:12px; }
.grid { display:grid; grid-template-columns: repeat(auto-fill,minmax(300px,1fr)); gap:14px; }
.thumb { width:100%; height:180px; object-fit:cover; border-radius:10px; }
.badge-status { position:absolute; top:12px; right:12px; padding:6px 10px; border-radius:10px; color:#fff; font-weight:700; }
@media (max-width:992px){ .admin-layout { grid-template-columns: 1fr; } }
</style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="../index.php"><img src="../assets/images/P.png" alt="PeerSquare" style="height:42px;"></a>
    <div class="ms-auto">
      <a class="btn btn-outline-light btn-sm" href="../index.php">Site</a>
      <a class="btn btn-danger btn-sm" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <div class="admin-layout">
    <?php include 'sidebar.php'; ?>

    <main>
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0">Marketplace Posts</h3>
        <a class="btn btn-outline-primary btn-sm" href="manage_marketplace.php">Refresh</a>
      </div>

      <div class="grid">
        <?php while($r = $res->fetch_assoc()): ?>
          <div class="card position-relative">
            <?php if(!empty($r['image']) && file_exists(__DIR__ . "/../uploads/".$r['image'])): ?>
              <img src="../uploads/<?php echo rawurlencode($r['image']); ?>" class="thumb" alt="">
            <?php else: ?>
              <div style="height:180px; display:flex;align-items:center;justify-content:center;background:#fff7f8;color:#c44;font-weight:700;border-radius:10px;">No image</div>
            <?php endif; ?>
            <div class="card-body">
              <h5><?php echo htmlspecialchars($r['title']); ?> <span class="small text-muted">RM <?php echo number_format($r['price'],2); ?></span></h5>
              <div class="small text-muted mb-2">Seller: <?php echo htmlspecialchars($r['name'] ?: 'Unknown'); ?></div>
              <p class="small text-muted mb-2"><?php echo nl2br(htmlspecialchars(strlen($r['description'])>200?substr($r['description'],0,200).'...':$r['description'])); ?></p>

              <div class="d-grid gap-2">
                <a class="btn btn-outline-secondary btn-sm" href="edit_marketplace.php?id=<?php echo intval($r['id']); ?>">Edit</a>

                <form method="post" onsubmit="return confirm('Approve this listing?');">
                  <input type="hidden" name="id" value="<?php echo intval($r['id']); ?>">
                  <?php if($r['status'] !== 'approved'): ?>
                    <button name="action" value="approve" class="btn btn-success btn-sm">Approve</button>
                  <?php endif; ?>
                </form>

                <?php if($r['status'] !== 'rejected'): ?>
                <form method="post" onsubmit="return confirm('Reject this listing?');">
                  <input type="hidden" name="id" value="<?php echo intval($r['id']); ?>">
                  <button name="action" value="reject" class="btn btn-warning btn-sm">Reject</button>
                </form>
                <?php endif; ?>

                <form method="post" onsubmit="return confirm('Delete this listing?');">
                  <input type="hidden" name="id" value="<?php echo intval($r['id']); ?>">
                  <button name="action" value="delete" class="btn btn-danger btn-sm">Delete</button>
                </form>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
      </div>

    </main>
  </div>
</div>
</body>
</html>
<?php
if(isset($stmt) && is_object($stmt)) $stmt->close();
$conn->close();
?>