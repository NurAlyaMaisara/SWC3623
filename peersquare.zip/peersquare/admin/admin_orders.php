<?php
// admin/admin_orders.php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){
  header("Location: ../login.php");
  exit;
}
include '../db_connect.php';

// Enable errors for debugging (remove or disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Messages
$success = $error = "";

// Handle POST actions: **hard-delete** an order (permanent)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_order'])) {
        $orderId = intval($_POST['delete_order']);
        if ($orderId > 0) {
            $conn->begin_transaction();
            try {
                // delete order_items
                $delItems = $conn->prepare("DELETE FROM order_items WHERE order_id=?");
                $delItems->bind_param("i", $orderId);
                $delItems->execute();
                $delItems->close();

                // delete the order itself
                $delOrder = $conn->prepare("DELETE FROM orders WHERE id=?");
                $delOrder->bind_param("i", $orderId);
                $delOrder->execute();
                $delOrder->close();

                $conn->commit();
                $success = "Order #$orderId permanently deleted.";
            } catch (Exception $ex) {
                $conn->rollback();
                $error = "Failed to permanently delete order.";
            }
        } else {
            $error = "Invalid order ID.";
        }
    }
    // Redirect to avoid form resubmission and display message
    if ($success || $error) {
        header("Location: admin_orders.php?msg=" . urlencode($success ?: $error));
        exit;
    }
}

// Notification from redirect
if (isset($_GET['msg']) && $_GET['msg'] !== '') {
    $success = trim($_GET['msg']);
}

// Export CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $expStmt = $conn->prepare("SELECT o.id, o.user_id, IFNULL(u.name,'Unknown') AS buyer_name, o.total_amount, o.payment_method, o.status, o.created_at FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC");
    $expStmt->execute();
    $expRes = $expStmt->get_result();

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=orders_export_' . date('Ymd_His') . '.csv');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['Order ID', 'Buyer ID', 'Buyer Name', 'Total Amount', 'Payment Method', 'Status', 'Placed At']);
    while ($row = $expRes->fetch_assoc()) {
        fputcsv($out, [
            $row['id'],
            $row['user_id'],
            $row['buyer_name'],
            number_format($row['total_amount'], 2, '.', ''),
            $row['payment_method'],
            $row['status'],
            $row['created_at']
        ]);
    }
    fclose($out);
    exit;
}

// Filters, search, pagination
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$statusFilter = isset($_GET['status']) ? trim($_GET['status']) : '';
$perPage = 20;
$page = isset($_GET['page']) ? max(1,intval($_GET['page'])) : 1;
$offset = ($page - 1) * $perPage;

// Build where clause
$where = "WHERE 1=1"; // changed to allow all orders (no soft-deleted filter)
$params = [];
$types = "";

if ($statusFilter !== '') {
    $where .= " AND o.status = ?";
    $params[] = $statusFilter;
    $types .= "s";
}
if ($q !== '') {
    $where .= " AND (CAST(o.id AS CHAR) = ? OR u.name LIKE ? OR u.email LIKE ?)";
    $params[] = $q;
    $params[] = "%{$q}%";
    $params[] = "%{$q}%";
    $types .= "sss";
}

// Count total for pagination
$countSql = "SELECT COUNT(*) AS c FROM orders o LEFT JOIN users u ON o.user_id = u.id $where";
if ($types) {
    $cStmt = $conn->prepare($countSql);
    $bind_names = [];
    $bind_names[] = $types;
    for ($i=0; $i<count($params); $i++){
        $bind_name = 'param' . $i;
        $$bind_name = $params[$i];
        $bind_names[] = &$$bind_name;
    }
    call_user_func_array([$cStmt, 'bind_param'], $bind_names);
    $cStmt->execute();
    $totalCount = $cStmt->get_result()->fetch_assoc()['c'];
    $cStmt->close();
} else {
    $totalCount = $conn->query($countSql)->fetch_assoc()['c'];
}
$totalPages = max(1, ceil($totalCount / $perPage));

// Fetch orders with limit/offset
$sql = "SELECT o.id, o.user_id, IFNULL(u.name,'Unknown') AS buyer_name, o.total_amount, o.payment_method, o.status, o.created_at
        FROM orders o LEFT JOIN users u ON o.user_id = u.id
        $where
        ORDER BY o.created_at DESC
        LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
if ($types) {
    $types_all = $types . "ii";
    $bind_names = [];
    $bind_names[] = $types_all;
    for ($i=0; $i<count($params); $i++){
        $bind_name = 'param' . $i;
        $$bind_name = $params[$i];
        $bind_names[] = &$$bind_name;
    }
    $bind_names[] = &$perPage;
    $bind_names[] = &$offset;
    call_user_func_array([$stmt, 'bind_param'], $bind_names);
} else {
    $stmt->bind_param("ii", $perPage, $offset);
}
$stmt->execute();
$res = $stmt->get_result();

// Totals for header (all orders)
$totalOrders = $conn->query("SELECT COUNT(*) AS c FROM orders")->fetch_assoc()['c'];
$totalRevenue = $conn->query("SELECT SUM(total_amount) AS s FROM orders")->fetch_assoc()['s'] ?: 0;

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>All Orders - Admin</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="../assets/css/style.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background:#faf6f7; }
    .container { max-width:1200px; }
    .page-header { display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:18px; }
    .big-revenue {
      background: linear-gradient(180deg,#fff,#f0fff0);
      border-radius:12px;
      padding:22px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.06);
      text-align:center;
      min-width:320px;
    }
    .big-revenue .label { color:#666; font-weight:700; margin-bottom:6px; display:block; }
    .big-revenue .amount { font-size:40px; color:#0a8f3c; font-weight:900; line-height:1; }
    .statbox { margin-bottom:18px; padding:12px 16px; background:#fff; border-radius:10px; display:flex; justify-content:space-between; font-weight:600; box-shadow:0 6px 18px rgba(0,0,0,0.03); }
    .table-card { padding:12px; border-radius:10px; background:#fff; box-shadow:0 6px 18px rgba(0,0,0,0.03); }
    .top-controls { display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin-bottom:12px; }
    .recent-empty { padding:18px; background:#f8fbff; border-radius:8px; color:#066; }
    @media (max-width:768px) {
      .page-header { flex-direction:column; align-items:flex-start; gap:10px; }
      .big-revenue { min-width:100%; }
    }
  </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="dashboard.php"><img src="../assets/images/P.png" alt="PeerSquare" style="height:38px;"></a>
    <div class="ms-auto">
      <a class="btn btn-outline-light btn-sm" href="dashboard.php">Dashboard</a>
      <a class="btn btn-danger btn-sm" href="../logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <div class="page-header">
    <div>
      <h3 class="mb-0">All Orders</h3>
      <div class="text-muted small">Manage and review orders</div>
    </div>
    <div class="d-flex gap-2 align-items-center">
      <a href="admin_orders.php" class="btn btn-outline-secondary btn-sm">Refresh</a>
      <a href="admin_orders.php?export=csv" class="btn btn-outline-primary btn-sm">Export CSV</a>
      <a href="dashboard.php" class="btn btn-outline-dark btn-sm">Back to Dashboard</a>
      <div class="big-revenue ms-3">
        <span class="label">Total Revenue</span>
        <span class="amount">RM <?php echo number_format($totalRevenue,2); ?></span>
      </div>
    </div>
  </div>

  <?php if($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
  <?php endif; ?>
  <?php if($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>

  <div class="statbox">
    <div>Total Orders: <strong><?php echo intval($totalOrders); ?></strong></div>
    <div>Showing: <strong><?php echo intval($totalCount); ?></strong> results</div>
  </div>

  <div class="card table-card">
    <div class="top-controls">
      <form class="d-flex" method="get" action="admin_orders.php" style="gap:8px; align-items:center;">
      </form>
      </div>
    </div>

    <?php if ($res->num_rows == 0): ?>
      <div class="recent-empty">No orders found for the selected criteria.</div>
    <?php else: ?>
      <div class="table-responsive">
      <table class="table table-striped table-sm mb-0">
        <thead>
          <tr>
            <th>Order #</th>
            <th>Buyer</th>
            <th class="text-end">Total (RM)</th>
            <th>Payment</th>
            <th>Status</th>
            <th>Date</th>
            <th class="text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php while($o = $res->fetch_assoc()): ?>
            <tr id="order-row-<?php echo intval($o['id']); ?>">
              <td><?php echo intval($o['id']); ?></td>
              <td>
                <?php if ($o['buyer_name'] !== 'Unknown'): ?>
                  <a href="edit_user.php?id=<?php echo intval($o['user_id']); ?>"><?php echo htmlspecialchars($o['buyer_name']); ?></a>
                  <div class="small text-muted">ID: <?php echo intval($o['user_id']); ?></div>
                <?php else: ?>
                  <div class="small text-muted">Guest (ID: <?php echo intval($o['user_id']); ?>)</div>
                <?php endif; ?>
              </td>
              <td class="text-end"><?php echo number_format($o['total_amount'],2); ?></td>
              <td><?php echo htmlspecialchars($o['payment_method']); ?></td>
              <td><?php echo htmlspecialchars(ucfirst($o['status'])); ?></td>
              <td><?php echo htmlspecialchars(date('M j, Y H:i', strtotime($o['created_at']))); ?></td>
              <td class="text-center">
                <div class="d-flex justify-content-center">
                  <form method="post" onsubmit="return confirm('Delete order #<?php echo intval($o['id']); ?> permanently? This cannot be undone.');" style="display:inline-block;margin-left:6px;">
                    <input type="hidden" name="delete_order" value="<?php echo intval($o['id']); ?>">
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
      </div>

      <!-- Pagination -->
      <div class="mt-3 d-flex justify-content-between align-items-center">
        <div class="small text-muted">Page <?php echo $page; ?> of <?php echo $totalPages; ?> (<?php echo intval($totalCount); ?> results)</div>
        <nav>
          <ul class="pagination pagination-sm mb-0">
            <li class="page-item <?php if($page<=1) echo 'disabled'; ?>">
              <a class="page-link" href="admin_orders.php?page=<?php echo $page-1; ?>&q=<?php echo urlencode($q); ?>&status=<?php echo urlencode($statusFilter); ?>">Prev</a>
            </li>
            <?php
            // show limited range of pages
            $start = max(1, $page - 3);
            $end = min($totalPages, $page + 3);
            for($p = $start; $p <= $end; $p++): ?>
              <li class="page-item <?php if($p == $page) echo 'active'; ?>">
                <a class="page-link" href="admin_orders.php?page=<?php echo $p; ?>&q=<?php echo urlencode($q); ?>&status=<?php echo urlencode($statusFilter); ?>"><?php echo $p; ?></a>
              </li>
            <?php endfor; ?>
            <li class="page-item <?php if($page >= $totalPages) echo 'disabled'; ?>">
              <a class="page-link" href="admin_orders.php?page=<?php echo $page+1; ?>&q=<?php echo urlencode($q); ?>&status=<?php echo urlencode($statusFilter); ?>">Next</a>
            </li>
          </ul>
        </nav>
      </div>
    <?php endif; ?>

  </div>
</div>

</body>
</html>