<?php
// admin/sidebar.php
// Shared admin sidebar. Expects $conn (db connection) and $_SESSION to be available.
// Safe fallback: try to include ../db_connect.php if $conn not set.
if (!isset($conn) && file_exists(__DIR__ . '/../db_connect.php')) {
    include __DIR__ . '/../db_connect.php';
}

// Safe counts with defaults
$usersCount = $marketCount = $pendingCount = $lostCount = 0;
if (isset($conn) && $conn instanceof mysqli) {
    $usersCount = intval(@$conn->query("SELECT COUNT(*) AS c FROM users")->fetch_assoc()['c'] ?? 0);
    $marketCount = intval(@$conn->query("SELECT COUNT(*) AS c FROM marketplace")->fetch_assoc()['c'] ?? 0);
    $pendingCount = intval(@$conn->query("SELECT COUNT(*) AS c FROM marketplace WHERE status='pending'")->fetch_assoc()['c'] ?? 0);
    $lostCount = intval(@$conn->query("SELECT COUNT(*) AS c FROM lostfound")->fetch_assoc()['c'] ?? 0);
}

// helper for active link
function is_active($file) {
    return (basename($_SERVER['PHP_SELF']) === $file) ? 'active' : '';
}
?>
<aside class="admin-sidebar" aria-label="Admin sidebar" style="padding:16px;border-radius:12px;background:linear-gradient(180deg,rgba(255,255,255,0.98),#fff);box-shadow:0 6px 18px rgba(0,0,0,0.04);">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
    <div>
      <h6 style="margin:0;color:var(--primary);font-weight:700;">Admin</h6>
      <div style="font-size:0.85rem;color:#666;">Control center</div>
    </div>
    <div style="text-align:right;">
      <div style="font-size:0.85rem;color:#666;">Signed in</div>
      <?php if(isset($_SESSION['user_id'])): ?>
        <div style="font-size:0.78rem;color:#999;margin-top:2px;">ID: <?php echo intval($_SESSION['user_id']); ?></div>
      <?php endif; ?>
    </div>
  </div>

  <nav aria-label="Admin navigation" style="margin-bottom:14px;">
    <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:6px;">
      <li>
        <a href="dashboard.php" class="<?php echo is_active('dashboard.php'); ?>" style="display:block;padding:10px;border-radius:8px;text-decoration:none;color:var(--text);background:transparent;">
          Dashboard
        </a>
      </li>
      <li>
        <a href="manage_users.php" class="<?php echo is_active('manage_users.php'); ?>" style="display:block;padding:10px;border-radius:8px;text-decoration:none;color:var(--text);background:transparent;">
          Manage Users
        </a>
      </li>
      <li>
        <a href="manage_marketplace.php" class="<?php echo is_active('manage_marketplace.php'); ?>" style="display:block;padding:10px;border-radius:8px;text-decoration:none;color:var(--text);background:transparent;">
          Manage Marketplace
        </a>
      </li>
      <li>
        <a href="manage_lostfound.php" class="<?php echo is_active('manage_lostfound.php'); ?>" style="display:block;padding:10px;border-radius:8px;text-decoration:none;color:var(--text);background:transparent;">
          Manage Lost/Found
        </a>
      </li>
    </ul>
  </nav>

  <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:14px;">
    <div style="background:#fff;padding:10px;border-radius:10px;box-shadow:0 6px 14px rgba(0,0,0,0.03);text-align:center;">
      <div style="font-size:0.78rem;color:#777;">Users</div>
      <div style="font-weight:700;font-size:1.05rem;"><?php echo $usersCount; ?></div>
    </div>
    <div style="background:#fff;padding:10px;border-radius:10px;box-shadow:0 6px 14px rgba(0,0,0,0.03);text-align:center;">
      <div style="font-size:0.78rem;color:#777;">Listings</div>
      <div style="font-weight:700;font-size:1.05rem;"><?php echo $marketCount; ?></div>
    </div>
    <div style="background:#fff;padding:10px;border-radius:10px;box-shadow:0 6px 14px rgba(0,0,0,0.03);text-align:center;">
      <div style="font-size:0.78rem;color:#777;">Pending</div>
      <div style="font-weight:700;font-size:1.05rem;"><?php echo $pendingCount; ?></div>
    </div>
    <div style="background:#fff;padding:10px;border-radius:10px;box-shadow:0 6px 14px rgba(0,0,0,0.03);text-align:center;">
      <div style="font-size:0.78rem;color:#777;">Lost/Found</div>
      <div style="font-weight:700;font-size:1.05rem;"><?php echo $lostCount; ?></div>
    </div>
  </div>

  <div style="margin-bottom:12px;">
    <div style="font-size:0.85rem;color:#666;margin-bottom:8px;">Quick filters</div>
    <div style="display:flex;flex-direction:column;gap:6px;">
      <a class="btn btn-sm btn-outline-primary" href="manage_marketplace.php?filter=pending" style="text-align:left">Pending listings</a>
      <a class="btn btn-sm btn-outline-primary" href="manage_marketplace.php?filter=approved" style="text-align:left">Approved listings</a>
      <a class="btn btn-sm btn-outline-primary" href="manage_marketplace.php?filter=rejected" style="text-align:left">Rejected listings</a>
      <a class="btn btn-sm btn-outline-secondary" href="manage_lostfound.php" style="text-align:left">All reports</a>
    </div>
  </div>

  <hr style="border:none;border-top:1px solid rgba(0,0,0,0.06);margin:12px 0;">

  <div style="margin-bottom:12px;">
    <div style="font-size:0.85rem;color:#666;margin-bottom:8px;">Quick search</div>
    <form id="adminQuickSearch" onsubmit="return adminQuickSearch(event)" style="display:flex;gap:8px;">
      <select id="adminSearchTarget" class="form-select form-select-sm" style="min-width:105px;">
        <option value="users">Users</option>
        <option value="marketplace">Marketplace</option>
        <option value="reports">Reports</option>
      </select>
      <input id="adminSearchQuery" class="form-control form-control-sm" placeholder="Search..." aria-label="Admin quick search">
    </form>
    <div style="display:flex;gap:8px;margin-top:8px;">
      <button class="btn btn-sm btn-primary w-100" onclick="adminQuickSearch(event)">Go</button>
    </div>
  </div>

  <div style="margin-top:6px;display:flex;flex-direction:column;gap:8px;">
    <a class="btn btn-sm btn-outline-light" href="../index.php">View site</a>
    <a class="btn btn-sm btn-danger" href="../logout.php">Logout</a>
  </div>

  <script>
    function adminQuickSearch(e) {
      if (e && e.preventDefault) e.preventDefault();
      var target = document.getElementById('adminSearchTarget').value;
      var q = encodeURIComponent(document.getElementById('adminSearchQuery').value || '');
      if (target === 'users') {
        window.location.href = 'manage_users.php?q=' + q;
      } else if (target === 'marketplace') {
        window.location.href = 'manage_marketplace.php?q=' + q;
      } else {
        window.location.href = 'manage_lostfound.php?q=' + q;
      }
      return false;
    }
  </script>
</aside>