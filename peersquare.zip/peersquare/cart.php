<?php
// cart.php
// Updated to keep original layout/styling but add "select subset to checkout" behavior.
// Users can update quantities, remove items, select any subset and click "Checkout selected".
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
$uid = intval($_SESSION['user_id']);

$success = $error = '';

// Handle quantity updates and single-item removal
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_qty']) && is_array($_POST['qty'])) {
        foreach ($_POST['qty'] as $cartId => $q) {
            $cartId = intval($cartId);
            $q = max(1, intval($q));
            $u = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE id = ? AND user_id = ?");
            if ($u) { $u->bind_param("iii", $q, $cartId, $uid); $u->execute(); $u->close(); }
        }
        $success = "Cart updated.";
    }
    if (isset($_POST['remove']) && intval($_POST['remove']) > 0) {
        $rid = intval($_POST['remove']);
        $d = $conn->prepare("DELETE FROM cart_items WHERE id = ? AND user_id = ?");
        if ($d) { $d->bind_param("ii", $rid, $uid); $d->execute(); $d->close(); $success = "Item removed."; }
    }
}

// Fetch cart items with original layout-friendly fields
$stmt = $conn->prepare("SELECT ci.id AS cart_id, m.id AS listing_id, m.title, m.price, ci.quantity, m.image FROM cart_items ci JOIN marketplace m ON ci.listing_id = m.id WHERE ci.user_id = ?");
$stmt->bind_param("i", $uid);
$stmt->execute();
$cart = $stmt->get_result();
$items = [];
$total = 0.0;
while ($r = $cart->fetch_assoc()) {
    $r['price'] = (float)$r['price'];
    $r['quantity'] = intval($r['quantity']);
    $r['subtotal'] = $r['price'] * $r['quantity'];
    $total += $r['subtotal'];
    $items[] = $r;
}
$stmt->close();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Your Cart — PeerSquare</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    .muted-small{color:#666;font-size:0.95rem}
    .product-thumb { width:80px; height:60px; object-fit:cover; border-radius:8px; }
    @media (max-width:576px){ .product-thumb { width:60px; height:48px; } }
  </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php"><img src="assets/images/P.png" alt="PeerSquare" style="height:38px;"></a>
    <div class="ms-auto">
      <a class="btn btn-outline-light btn-sm" href="marketplace.php">Continue shopping</a>
      <a class="btn btn-danger btn-sm" href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <h3>Your Cart</h3>
  <?php if($success): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
  <?php if($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

  <?php if(empty($items)): ?>
    <div class="card p-3">
      <p>Your cart is empty. Browse the <a href="marketplace.php">marketplace</a> to add items.</p>
      <div class="mt-2">
        <a class="btn btn-primary" href="marketplace.php">Browse marketplace</a>
      </div>
    </div>
  <?php else: ?>
    <form method="post" id="cartForm">
      <div class="card mb-3">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table align-middle mb-0">
              <thead>
                <tr>
                  <th style="width:36px"></th>
                  <th>Item</th>
                  <th style="width:120px">Price</th>
                  <th style="width:120px">Quantity</th>
                  <th style="width:140px" class="text-end">Subtotal</th>
                  <th style="width:90px"></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach($items as $it): ?>
                  <tr>
                    <td><input type="checkbox" name="selected[]" value="<?php echo intval($it['cart_id']); ?>"></td>
                    <td>
                      <div class="d-flex align-items-center gap-3">
                        <?php if(!empty($it['image']) && file_exists(__DIR__ . '/uploads/' . $it['image'])): ?>
                          <img src="uploads/<?php echo rawurlencode($it['image']); ?>" class="product-thumb" alt="">
                        <?php else: ?>
                          <div class="product-thumb" style="background:#f7f7f8;display:flex;align-items:center;justify-content:center;color:#c44;font-weight:700;">No image</div>
                        <?php endif; ?>
                        <div>
                          <div style="font-weight:700;"><?php echo htmlspecialchars($it['title']); ?></div>
                          <div class="small text-muted">Listing ID: <?php echo intval($it['listing_id']); ?></div>
                        </div>
                      </div>
                    </td>
                    <td>RM <?php echo number_format($it['price'],2); ?></td>
                    <td>
                      <input type="number" name="qty[<?php echo intval($it['cart_id']); ?>]" value="<?php echo intval($it['quantity']); ?>" min="1" class="form-control form-control-sm" style="width:90px;">
                    </td>
                    <td class="text-end">RM <?php echo number_format($it['subtotal'],2); ?></td>
                    <td class="text-end">
                      <button type="submit" name="remove" value="<?php echo intval($it['cart_id']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Remove this item?')">Remove</button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
              <tfoot>
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td class="text-end muted-small"><strong>Total</strong></td>
                  <td class="text-end"><strong>RM <?php echo number_format($total,2); ?></strong></td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>

      <div class="d-flex gap-2">
        <button type="submit" name="update_qty" class="btn btn-outline-secondary">Update quantities</button>

        <!-- Proceed to checkout for selected items -->
        <button type="button" class="btn btn-primary" onclick="submitCheckout()">Checkout selected</button>

        <a class="btn btn-outline-primary ms-auto" href="marketplace.php">Continue shopping</a>
      </div>
    </form>

    <form id="toCheckout" method="post" action="checkout.php" style="display:none;">
      <!-- selected[] will be appended by JS -->
    </form>

    <script>
      function submitCheckout(){
        var checked = document.querySelectorAll('input[name="selected[]"]:checked');
        if(checked.length === 0){
          alert('Please select at least one item to checkout.');
          return;
        }
        var target = document.getElementById('toCheckout');
        target.innerHTML = '';
        checked.forEach(function(cb){
          var input = document.createElement('input');
          input.type = 'hidden';
          input.name = 'selected[]';
          input.value = cb.value;
          target.appendChild(input);
        });
        // Also include current quantities for those selected items to allow final adjustments
        checked.forEach(function(cb){
          var cartId = cb.value;
          var qtyInput = document.querySelector('input[name="qty['+cartId+']"]');
          if(qtyInput){
            var q = document.createElement('input');
            q.type = 'hidden';
            q.name = 'qty['+cartId+']';
            q.value = qtyInput.value;
            target.appendChild(q);
          }
        });
        target.submit();
      }
    </script>
  <?php endif; ?>
</div>
</body>
</html>