<?php
// cart_add.php
// AJAX endpoint: add an item to the logged-in user's cart (JSON response).
session_start();
include 'db_connect.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'login_required']);
    exit;
}

$user_id = intval($_SESSION['user_id']);
$listing_id = isset($_POST['listing_id']) ? intval($_POST['listing_id']) : 0;
$qty = isset($_POST['quantity']) ? max(1, intval($_POST['quantity'])) : 1;
if ($listing_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'invalid_listing']);
    exit;
}

// load listing and check existence/status (no stock checks)
$stmt = $conn->prepare("SELECT id, title, price, status FROM marketplace WHERE id = ?");
$stmt->bind_param("i", $listing_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row || $row['status'] !== 'approved') {
    http_response_code(404);
    echo json_encode(['error' => 'not_available']);
    exit;
}

// upsert into cart_items (no stock constraints)
$chk = $conn->prepare("SELECT id, quantity FROM cart_items WHERE user_id = ? AND listing_id = ?");
$chk->bind_param("ii", $user_id, $listing_id);
$chk->execute();
$existing = $chk->get_result()->fetch_assoc();
$chk->close();

if ($existing) {
    $newQty = intval($existing['quantity']) + $qty;
    $upd = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE id = ?");
    $upd->bind_param("ii", $newQty, $existing['id']);
    $ok = $upd->execute();
    $upd->close();
} else {
    $ins = $conn->prepare("INSERT INTO cart_items (user_id, listing_id, quantity) VALUES (?, ?, ?)");
    $ins->bind_param("iii", $user_id, $listing_id, $qty);
    $ok = $ins->execute();
    $ins->close();
}

if ($ok) {
    // return updated cart count
    $cnt = $conn->prepare("SELECT COALESCE(SUM(quantity),0) AS c FROM cart_items WHERE user_id = ?");
    $cnt->bind_param("i", $user_id);
    $cnt->execute();
    $c = intval($cnt->get_result()->fetch_assoc()['c'] ?? 0);
    $cnt->close();

    echo json_encode(['ok' => true, 'cart_count' => $c]);
    exit;
}

http_response_code(500);
echo json_encode(['error' => 'db_error']);
exit;