<?php
session_start();
session_unset();
session_destroy();
// Clear admin cookie if set
setcookie('is_admin', '', time() - 3600, '/');
header("Location: index.php");
exit;
?>