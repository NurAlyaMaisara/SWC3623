<?php
session_start();
include 'db_connect.php';
$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $email = strtolower(trim($_POST['email']));
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $res = $stmt->get_result();
    if($user = $res->fetch_assoc()){
        if(password_verify($password, $user['password'])){
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            // prefer admin dashboard if admin
            if($user['role'] === 'admin'){
                header("Location: admin/dashboard.php");
            } else {
                header("Location: index.php");
            }
            exit;
        } else $error = "Invalid credentials";
    } else $error = "Invalid credentials";
    $stmt->close();
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Login | PeerSquare</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    /* small page-specific tweaks */
    .auth-card { max-width: 920px; margin: 40px auto; border-radius: 14px; overflow: hidden; }
    .auth-left {
      background: linear-gradient(180deg, rgba(255,75,92,0.06), rgba(255,106,136,0.03));
      padding: 28px;
      display:flex;
      flex-direction:column;
      justify-content:center;
      align-items:center;
      min-height: 320px;
    }
    .brand-mark {
      width:84px; height:84px; border-radius:12px; background:#fff; display:flex; align-items:center; justify-content:center; box-shadow: 0 8px 24px rgba(0,0,0,0.06);
    }
    .brand-mark img { height:44px; }
    .auth-right { padding:28px; }
    .form-footer { display:flex; justify-content:space-between; align-items:center; gap:12px; }
    .password-toggle { cursor:pointer; color:var(--primary); font-weight:600; }
    .spinner-border-sm { width:1rem; height:1rem; border-width: .12rem; }
    @media (max-width: 767px) {
      .auth-left { padding:18px; min-height:160px; }
      .auth-card { margin: 18px; }
    }
  </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-dark">
  <div class="container d-flex justify-content-between align-items-center">
    <!-- logo: image only -->
    <a class="navbar-brand d-flex align-items-center" href="index.php" aria-label="PeerSquare" title="PeerSquare">
      <img src="assets/images/P.png" alt="PeerSquare" style="height:38px; margin-right:8px;">
    </a>
    <div class="d-flex align-items-center">
      <a href="marketplace.php" class="nav-link px-3 text-white">Marketplace</a>
      <a href="register.php" class="btn btn-outline-light btn-sm mx-1">Register</a>
    </div>
  </div>
</nav>

<div class="container">
  <div class="card auth-card shadow-sm">
    <div class="row g-0">
      <div class="col-md-5 auth-left text-center">
        <div class="brand-mark mb-3">
          <img src="assets/images/P.png" alt="PeerSquare">
        </div>
        <h4 class="kicker">Welcome back</h4>
        <p class="text-muted" style="max-width:220px;">Log in to access your profile, post listings, and manage your reports.</p>
        <div class="mt-3">
          <a href="register.php" class="btn btn-primary btn-sm">Create an account</a>
        </div>
      </div>

      <div class="col-md-7 auth-right">
        <h4 class="mb-3">Login</h4>

        <?php if($error): ?>
          <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form id="loginForm" method="post" action="login.php" novalidate>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control" name="email" type="email" placeholder="you@example.com" required>
          </div>

          <div class="mb-3 position-relative">
            <label class="form-label">Password</label>
            <div class="input-group">
              <input id="password" class="form-control" name="password" type="password" placeholder="Your password" required>
              <button id="togglePwd" class="btn btn-outline-secondary" type="button" title="Show / hide password">Show</button>
            </div>
          </div>

          <div class="mb-3 form-footer">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="remember" name="remember">
              <label class="form-check-label small" for="remember">Remember me</label>
            </div>
            <div class="small text-muted">Forgot password? Contact support</div>
          </div>

          <div class="d-flex gap-2">
            <button id="loginBtn" class="btn btn-primary w-100" type="submit">
              <span id="btnText">Login</span>
              <span id="btnSpinner" class="spinner-border spinner-border-sm ms-2" role="status" aria-hidden="true" style="display:none;"></span>
            </button>
          </div>

          <div class="mt-3 text-center small text-muted">
            Don't have an account? <a href="register.php">Register</a>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<footer class="footer" style="position:fixed;bottom:0;left:0;right:0;">
  PeerSquare — Student Marketplace
</footer>

<script>
(function(){
  // Toggle password visibility
  var pwd = document.getElementById('password');
  var toggle = document.getElementById('togglePwd');
  toggle.addEventListener('click', function(){
    if(pwd.type === 'password'){ pwd.type = 'text'; toggle.textContent = 'Hide'; }
    else { pwd.type = 'password'; toggle.textContent = 'Show'; }
    pwd.focus();
  });

  // Disable double-submit and show spinner
  var form = document.getElementById('loginForm');
  var loginBtn = document.getElementById('loginBtn');
  var btnText = document.getElementById('btnText');
  var btnSpinner = document.getElementById('btnSpinner');
  form.addEventListener('submit', function(e){
    // basic client-side validation
    var email = form.querySelector('[name=email]').value.trim();
    var password = form.querySelector('[name=password]').value;
    if(!email || !password){
      alert('Please enter both email and password.');
      e.preventDefault();
      return false;
    }
    // show spinner and prevent multiple submits
    loginBtn.disabled = true;
    btnSpinner.style.display = 'inline-block';
    btnText.textContent = 'Signing in...';
  });
})();
</script>

</body>
</html>