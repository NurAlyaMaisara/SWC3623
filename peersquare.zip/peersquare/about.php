<?php
session_start();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>About Us — PeerSquare</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    /* Page-specific styles for About */
    .hero-about {
      background: linear-gradient(180deg,#fff,#fff7f8);
      border-radius: 12px;
      padding: 36px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.04);
      display:flex;
      gap:24px;
      align-items:center;
    }
    .hero-about .lead { color:#555; }
    .feature-card { background:#fff; padding:18px; border-radius:10px; box-shadow:0 6px 18px rgba(0,0,0,0.03); }
    .btn-cta { min-width:150px; }
    .faq { margin-top:20px; }
    @media (max-width:768px) {
      .hero-about { flex-direction:column; text-align:center; padding:20px; }
    }
  </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="assets/images/P.png" alt="PeerSquare" style="height:40px; margin-right:8px;">
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain" aria-controls="navMain" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="marketplace.php">Marketplace</a></li>
        <li class="nav-item"><a class="nav-link" href="lostfound.php">Lost &amp; Found</a></li>
        <li class="nav-item"><a class="nav-link active" href="about.php">About</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
        <?php if(isset($_SESSION['user_id'])): ?>
          <li class="nav-item"><a class="btn btn-outline-light btn-sm ms-2" href="profile.php">Profile</a></li>
          <li class="nav-item"><a class="btn btn-danger btn-sm ms-2" href="logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="btn btn-outline-light btn-sm ms-2" href="login.php">Login</a></li>
          <li class="nav-item"><a class="btn btn-primary btn-sm ms-2" href="register.php">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<main class="container my-5">

  <!-- Hero -->
  <section class="hero-about">
    <div style="flex:1;">
      <h1 style="margin-bottom:6px;">About PeerSquare</h1>
      <p class="lead">PeerSquare is a student-first marketplace where students can buy and sell textbooks, electronics and report lost &amp; found items within their campus community.</p>

      <div class="d-flex flex-wrap gap-2 mt-3">
        <a href="marketplace.php" class="btn btn-primary btn-cta">Browse Marketplace</a>
        <a href="sell.php" class="btn btn-outline-primary btn-cta">Post an item</a>
        <a href="lostfound.php" class="btn btn-outline-secondary btn-cta">Lost &amp; Found</a>
      </div>
    </div>

    <div style="width:320px; max-width:40%;">
      <div class="feature-card text-center">
        <h5 style="margin-bottom:6px;">Our Mission</h5>
        <p class="small text-muted mb-2">We aim to provide a safe, simple and reliable place for students to trade items and help reunite lost items with their owners.</p>
        <a href="contact.php" class="btn btn-outline-primary btn-sm">Get in touch</a>
      </div>
    </div>
  </section>

  <!-- FAQ / small help -->
  <section class="faq">
    <h3 class="mb-3">Quick help</h3>
    <div class="accordion" id="aboutFaq">
      <div class="accordion-item">
        <h2 class="accordion-header" id="faqOne">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
            How do I post an item?
          </button>
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="faqOne" data-bs-parent="#aboutFaq">
          <div class="accordion-body small">
            Create an account, go to "Post an item", fill in details and upload an image. Admins will review and publish approved listings.
          </div>
        </div>
      </div>

      <div class="accordion-item">
        <h2 class="accordion-header" id="faqTwo">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            What should I do if I find a lost item?
          </button>
        </h2>
        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="faqTwo" data-bs-parent="#aboutFaq">
          <div class="accordion-body small">
            Report the item on the Lost &amp; Found page with a photo and location details so the owner can contact you.
          </div>
        </div>
      </div>
    </div>
  </section>

  <div class="my-4 text-center">
    <a href="marketplace.php" class="btn btn-lg btn-primary">Browse marketplace</a>
    <a href="contact.php" class="btn btn-lg btn-outline-secondary ms-2">Contact us</a>
  </div>

</main>

<footer class="footer py-3 bg-white" style="border-top:1px solid rgba(0,0,0,0.04);">
  <div class="container text-center small text-muted">&copy; <?php echo date('Y'); ?> PeerSquare</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>