<?php
session_start();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>PeerSquare — Student Marketplace</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    /* Slightly reduced hero height so cards sit higher */
    .hero {
      min-height: 68vh;
      display:flex;
      align-items:center;
      background: linear-gradient(180deg, #fff, #fff7f8);
      border-radius: 14px;
      padding: 48px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.04);
    }
    .feature-card { border-radius:12px; background:#fff; box-shadow:0 8px 30px rgba(0,0,0,0.04); padding:22px; }
    .quick-links .btn { min-width:180px; }
    #heroPreviewWrap { width:360px; max-width:40%; }
    .hero-bottom-gap { height: 40px; }
    .page-spacer { height: 120px; }
    @media (max-width:768px){
      .hero { padding:18px; flex-direction:column; gap:18px; min-height:54vh; }
      .quick-links { display:flex; flex-direction:column; gap:8px; }
      #heroPreviewWrap { width:100%; max-width:none; }
      .hero-bottom-gap { height: 24px; }
      .page-spacer { height: 80px; }
    }
  </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php" aria-label="PeerSquare" title="PeerSquare">
      <img src="assets/images/P.png" alt="PeerSquare logo" style="height:42px;">
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain" aria-controls="navMain" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link" href="marketplace.php">Marketplace</a></li>
        <li class="nav-item"><a class="nav-link" href="lostfound.php">Lost &amp; Found</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
        <?php
          // Show admin dashboard button if session role = admin OR admin cookie present
          $is_admin = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') || (isset($_COOKIE['is_admin']) && $_COOKIE['is_admin'] === '1');
          if(isset($_SESSION['user_id']) || $is_admin):
        ?>
          <?php if ($is_admin): ?>
            <li class="nav-item"><a class="btn btn-warning btn-sm ms-2" href="admin/dashboard.php">Admin</a></li>
          <?php endif; ?>
          <li class="nav-item"><a class="btn btn-outline-light btn-sm ms-2" href="profile.php">Profile</a></li>
          <li class="nav-item"><a class="btn btn-danger btn-sm ms-2" href="logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="btn btn-outline-light btn-sm ms-2" href="login.php">Login</a></li>
          <li class="nav-item"><a class="btn btn-primary btn-sm ms-2" href="register.php">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<div class="container my-5">
  <div class="hero">
    <div class="flex-grow-1 pe-4">
      <h1 class="display-5" style="font-weight:700;">PeerSquare — Student Marketplace</h1>
      <p class="lead text-muted">Buy, sell and report lost &amp; found items within your campus community. Safe, simple and student-friendly.</p>

      <div class="quick-links d-flex gap-3 mt-4">
        <a href="marketplace.php" class="btn btn-outline-primary btn-lg">Browse Marketplace</a>
        <a href="lostfound.php" class="btn btn-outline-secondary btn-lg">Lost &amp; Found</a>
        <a href="sell.php" class="btn btn-primary btn-lg">Post an item</a>
      </div>

      <p class="text-muted mt-3 small">You can also learn more <a href="about.php">about us</a> or <a href="contact.php">get in touch</a>.</p>
    </div>

    <div id="heroPreviewWrap" class="d-none d-md-block">
      <div class="feature-card text-center">
        <div id="heroImageContainer" aria-hidden="true"></div>

        <h5 style="margin-bottom:6px;">Quick actions</h5>
        <p class="text-muted small">Jump straight to the sections you need.</p>
        <div class="d-grid gap-2 mt-2">
          <a class="btn btn-outline-primary" href="marketplace.php">Marketplace</a>
          <a class="btn btn-outline-secondary" href="lostfound.php">Lost &amp; Found</a>
          <a class="btn btn-outline-success" href="sell.php">Sell an item</a>
        </div>
      </div>
    </div>
  </div>

  <div class="hero-bottom-gap" aria-hidden="true"></div>

  <div class="row mt-2 gy-4">
    <div class="col-md-4">
      <div class="card p-3">
        <h5>How it works</h5>
        <p class="text-muted small">Post items, browse listings or report lost &amp; found items. Admin reviews listings before publishing.</p>
        <a href="about.php" class="btn btn-sm btn-outline-primary">Learn more</a>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card p-3">
        <h5>Safety</h5>
        <p class="text-muted small">Communicate using the contact provided in listings. Meet on campus in public areas.</p>
        <a href="contact.php" class="btn btn-sm btn-outline-secondary">Contact support</a>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card p-3">
        <h5>Need help?</h5>
        <p class="text-muted small">Visit the Lost &amp; Found page if you lost an item or want to report something found on campus.</p>
        <a href="lostfound.php" class="btn btn-sm btn-outline-success">Report an item</a>
      </div>
    </div>
  </div>

  <div class="page-spacer" aria-hidden="true"></div>
</div>

<footer class="footer py-3 bg-white" style="border-top:1px solid rgba(0,0,0,0.04);">
  <div class="container text-center small text-muted">
    &copy; <?php echo date('Y'); ?> PeerSquare — Student Marketplace • <a href="about.php">About</a> • <a href="contact.php">Contact</a>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function() {
  var imgSrc = '/assets/images/hero-marketplace.png';
  var container = document.getElementById('heroImageContainer');
  var wrapper = document.getElementById('heroPreviewWrap');
  if (!container || !wrapper) return;
  var img = new Image();
  img.onload = function() {
    img.alt = 'Marketplace preview';
    img.className = 'img-fluid';
    container.appendChild(img);
    wrapper.classList.remove('d-none');
  };
  img.onerror = function() { wrapper.classList.remove('d-none'); };
  img.src = imgSrc;
})();
</script>
</body>
</html>