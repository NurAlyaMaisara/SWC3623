<?php
// order_success.php - improved design/layout and working buttons (print / download / view orders / continue shopping)
// Usage: replace your current order_success.php with this file.
//
// Notes:
// - Requires db_connect.php to provide $conn (mysqli).
// - User must be logged in; otherwise redirects to login.php.
// - Order must belong to current user; otherwise shows error.
// - This version adds nicer layout, status badge, print/download receipt, and an auto-redirect countdown with cancel.

session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = intval($_SESSION['user_id']);
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch order
$stmt = $conn->prepare("SELECT id, user_id, total_amount, status, payment_method, payment_ref, created_at FROM orders WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    http_response_code(404);
    echo "<!doctype html><html><body><h2>Order not found</h2><p>The order does not exist or you don't have permission to view it.</p><p><a href='marketplace.php'>Back to marketplace</a></p></body></html>";
    exit;
}

// Fetch items
$it = $conn->prepare("SELECT listing_id, title, price, quantity, subtotal FROM order_items WHERE order_id = ?");
$it->bind_param("i", $order_id);
$it->execute();
$items = $it->get_result();
$it->close();

// Format helpers
function h($v) { return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }
function statusBadge($s) {
    $map = [
        'pending'         => ['bg' => 'bg-warning text-dark', 'label' => 'Pending'],
        'pending_payment' => ['bg' => 'bg-warning text-dark', 'label' => 'Pending payment'],
        'paid'            => ['bg' => 'bg-success text-white', 'label' => 'Paid'],
        'shipped'         => ['bg' => 'bg-info text-white', 'label' => 'Shipped'],
        'completed'       => ['bg' => 'bg-primary text-white', 'label' => 'Completed'],
        'canceled'        => ['bg' => 'bg-secondary text-white', 'label' => 'Cancelled'],
        'cancelled'       => ['bg' => 'bg-secondary text-white', 'label' => 'Cancelled'],
        'deleted'         => ['bg' => 'bg-dark text-white', 'label' => 'Deleted'],
    ];
    $s = strtolower($s);
    $c = $map[$s] ?? ['bg' => 'bg-secondary text-white', 'label' => ucfirst($s)];
    return "<span class=\"badge {$c['bg']}\" style=\"font-size:0.95rem; padding:0.6em 0.8em;\">".h($c['label'])."</span>";
}

// Redirect config: change target/delay if you want
$redirectTarget = 'marketplace.php';
$delaySeconds = 30; // seconds to auto-redirect; user can cancel
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Order #<?php echo intval($order_id); ?> — PeerSquare</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    /* Order page tweaks */
    .order-header { margin-top: 28px; margin-bottom:18px; }
    .order-meta { color:#6c757d; font-size:0.95rem; }
    .receipt-card { border-radius:10px; box-shadow:0 6px 20px rgba(22,28,36,0.04); }
    .receipt-line { padding:18px 20px; }
    .receipt-line + .receipt-line { border-top:1px solid rgba(0,0,0,0.06); }
    .total-row { font-weight:700; font-size:1.05rem; }
    .btn-ghost { border:1px solid rgba(0,0,0,0.08); background:#fff; }
    @media (max-width:576px) {
      .receipt-line { padding:12px; }
      .order-header { padding-left:12px; padding-right:12px; }
    }
  </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php"><img src="assets/images/P.png" alt="PeerSquare" style="height:38px;"></a>
    <div class="ms-auto d-flex gap-2">
      <a class="btn btn-outline-light btn-sm" href="marketplace.php">Marketplace</a>
      <a class="btn btn-outline-light btn-sm" href="lostfound.php">Lost & Found</a>
      <a class="btn btn-outline-light btn-sm" href="profile.php">Profile</a>
      <a class="btn btn-danger btn-sm" href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container">
  <div class="order-header">
    <h2>Order #<?php echo intval($order['id']); ?></h2>
    <div class="d-flex flex-wrap align-items-center gap-3">
      <div class="order-meta">Placed on <?php echo h(date('M j, Y, H:i', strtotime($order['created_at']))); ?></div>
      <div><?php echo statusBadge($order['status']); ?></div>
      <?php if(!empty($order['payment_method'])): ?>
        <div class="order-meta">Payment: <?php echo h(ucfirst($order['payment_method'])); ?><?php if(!empty($order['payment_ref'])) echo ' • Ref: '.h($order['payment_ref']); ?></div>
      <?php endif; ?>
    </div>
  </div>

  <div class="row gy-3">
    <div class="col-lg-8">
      <div class="card receipt-card">
        <div class="receipt-line">
          <div class="d-flex justify-content-between align-items-start">
            <div>
              <h5 style="margin:0;">Items</h5>
              <div class="text-muted small">Summary of items in this order</div>
            </div>
            <div class="text-end">
              <button id="printBtn" class="btn btn-outline-secondary btn-sm me-1" title="Print receipt">Print</button>
              <button id="downloadBtn" class="btn btn-outline-secondary btn-sm" title="Download receipt">Download</button>
            </div>
          </div>
        </div>

        <?php
          // show items as list
          $items->data_seek(0);
          while($row = $items->fetch_assoc()):
        ?>
          <div class="receipt-line d-flex justify-content-between align-items-center">
            <div>
              <div style="font-weight:600;"><?php echo h($row['title']); ?> <span class="text-muted" style="font-weight:400;">× <?php echo intval($row['quantity']); ?></span></div>
              <?php if(!empty($row['listing_id'])): ?>
                <div class="text-muted small">Product ID: <?php echo intval($row['listing_id']); ?></div>
              <?php endif; ?>
            </div>
            <div class="text-end">RM <?php echo number_format(floatval($row['subtotal']), 2); ?></div>
          </div>
        <?php endwhile; ?>

        <div class="receipt-line d-flex justify-content-between align-items-center">
          <div class="total-row">Total</div>
          <div class="total-row">RM <?php echo number_format(floatval($order['total_amount']), 2); ?></div>
        </div>
      </div>

      <div class="mt-3 d-flex flex-wrap gap-2">
        <a class="btn btn-primary" href="marketplace.php" id="continueBtn">Continue shopping</a>
        <a class="btn btn-ghost" href="profile.php">View my orders</a>
        <!-- Optionally allow contacting seller or admin: -->
        <a class="btn btn-outline-secondary" href="contact.php">Contact support</a>
      </div>

      <div class="mt-3 text-muted small">
        You will be redirected to the marketplace in <strong id="redirectCountdown"><?php echo intval($delaySeconds); ?></strong> seconds.
        <button id="cancelRedirect" class="btn btn-link btn-sm">Cancel</button>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="card p-3">
        <h6 class="mb-2">Order details</h6>
        <div class="small text-muted mb-2">Order ID</div>
        <div class="mb-2"><strong>#<?php echo intval($order['id']); ?></strong></div>

        <div class="small text-muted mb-2">Placed</div>
        <div class="mb-2"><?php echo h(date('M j, Y H:i', strtotime($order['created_at']))); ?></div>

        <div class="small text-muted mb-2">Status</div>
        <div class="mb-2"><?php echo statusBadge($order['status']); ?></div>

        <?php if(!empty($order['payment_method'])): ?>
          <div class="small text-muted mb-2">Payment</div>
          <div class="mb-2"><?php echo h(ucfirst($order['payment_method'])); ?></div>
        <?php endif; ?>

        <div class="small text-muted mb-2">Total</div>
        <div class="mb-2"><strong>RM <?php echo number_format(floatval($order['total_amount']), 2); ?></strong></div>

        <div class="mt-3">
          <a class="btn btn-outline-primary w-100" href="profile.php">Manage orders</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
  // Auto-redirect with cancel
  var delay = <?php echo intval($delaySeconds); ?>;
  var target = '<?php echo $redirectTarget; ?>';
  var counterEl = document.getElementById('redirectCountdown');
  var cancelBtn = document.getElementById('cancelRedirect');
  var timer = null;

  function startCountdown() {
    var remaining = delay;
    counterEl.textContent = remaining;
    timer = setInterval(function(){
      remaining--;
      if (remaining <= 0) {
        clearInterval(timer);
        window.location.href = target;
      } else {
        counterEl.textContent = remaining;
      }
    }, 1000);
  }

  cancelBtn.addEventListener('click', function(e){
    e.preventDefault();
    if (timer) {
      clearInterval(timer);
      timer = null;
      counterEl.textContent = 'cancelled';
      cancelBtn.style.display = 'none';
    }
  });

  startCountdown();

  // Print button
  document.getElementById('printBtn').addEventListener('click', function(){
    window.print();
  });

  // Download button - produce a simple receipt text file
  document.getElementById('downloadBtn').addEventListener('click', function(){
    var orderId = <?php echo intval($order['id']); ?>;
    var createdAt = '<?php echo h($order['created_at']); ?>';
    var status = '<?php echo h($order['status']); ?>';
    var payment = '<?php echo h($order['payment_method'] ?? ''); ?>';
    var total = '<?php echo number_format(floatval($order['total_amount']), 2); ?>';

    // collect items
    var rows = [];
    <?php
      $items->data_seek(0);
      while($r = $items->fetch_assoc()):
        $title = addslashes($r['title']);
        $qty = intval($r['quantity']);
        $sub = number_format(floatval($r['subtotal']), 2);
    ?>
    rows.push("<?php echo $title; ?> × <?php echo $qty; ?> — RM <?php echo $sub; ?>");
    <?php endwhile; ?>

    var content = "PeerSquare - Order #" + orderId + "\n";
    content += "Placed: " + createdAt + "\n";
    content += "Status: " + status + "\n";
    if (payment) content += "Payment: " + payment + "\n";
    content += "\nItems:\n" + rows.join("\n") + "\n\n";
    content += "Total: RM " + total + "\n";
    // trigger download
    var blob = new Blob([content], {type: 'text/plain;charset=utf-8;'});
    var filename = 'order-' + orderId + '.txt';
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(blob, filename);
    } else {
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      setTimeout(function(){ URL.revokeObjectURL(a.href); a.remove(); }, 5000);
    }
  });

  // Make sure "Continue shopping" and "View my orders" buttons work — they are plain anchors.
})();
</script>
</body>
</html>