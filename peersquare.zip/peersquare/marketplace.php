<?php
session_start();
include 'db_connect.php';

// compute cart count for navbar
$cart_count = 0;
if (isset($_SESSION['user_id'])) {
    $uid = intval($_SESSION['user_id']);
    $cstmt = $conn->prepare("SELECT COALESCE(SUM(quantity),0) AS c FROM cart_items WHERE user_id = ?");
    $cstmt->bind_param("i", $uid);
    $cstmt->execute();
    $cart_count = intval($cstmt->get_result()->fetch_assoc()['c'] ?? 0);
    $cstmt->close();
}

// search & pagination
$search = '';
if (isset($_GET['q'])) $search = trim($_GET['q']);
$page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$perPage = 9;
$offset = ($page - 1) * $perPage;

// prepare query (approved listings only)
if ($search !== '') {
    $like = '%' . $search . '%';
    $countStmt = $conn->prepare("SELECT COUNT(*) AS c FROM marketplace m WHERE m.status='approved' AND (m.title LIKE ? OR m.description LIKE ?)");
    $countStmt->bind_param("ss", $like, $like);
    $countStmt->execute();
    $total = intval($countStmt->get_result()->fetch_assoc()['c'] ?? 0);
    $countStmt->close();

    $stmt = $conn->prepare("SELECT m.*, u.name FROM marketplace m LEFT JOIN users u ON m.user_id = u.id WHERE m.status='approved' AND (m.title LIKE ? OR m.description LIKE ?) ORDER BY m.created_at DESC LIMIT ?, ?");
    $stmt->bind_param("ssii", $like, $like, $offset, $perPage);
} else {
    $total = intval($conn->query("SELECT COUNT(*) AS c FROM marketplace WHERE status='approved'")->fetch_assoc()['c'] ?? 0);
    $stmt = $conn->prepare("SELECT m.*, u.name FROM marketplace m LEFT JOIN users u ON m.user_id = u.id WHERE m.status='approved' ORDER BY m.created_at DESC LIMIT ?, ?");
    $stmt->bind_param("ii", $offset, $perPage);
}

$stmt->execute();
$result = $stmt->get_result();
$totalPages = ($total > 0) ? ceil($total / $perPage) : 1;
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Marketplace</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    .card .card-body { padding: 12px; }
    .marketplace-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 18px; }
    .product-thumb { height: 180px; object-fit: cover; border-bottom-left-radius: 12px; border-bottom-right-radius: 12px; width:100%; display:block; }
    .marketplace-card .card-body h5 { margin-bottom: 6px; }
    .truncate-3 { display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
    .navbar .navbar-brand img { vertical-align: middle; }
    .cart-badge { background:#ff6b6b; color:#fff; font-weight:700; padding:4px 8px; border-radius:999px; font-size:0.85rem; }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php" aria-label="PeerSquare" title="PeerSquare">
      <img src="assets/images/P.png" alt="PeerSquare logo" style="height:45px;">
    </a>

    <div class="ms-auto d-flex align-items-center gap-2">
      <?php
        $is_admin = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') || (isset($_COOKIE['is_admin']) && $_COOKIE['is_admin'] === '1');
      ?>
      <?php if(isset($_SESSION['user_id']) || $is_admin): ?>
        <?php if ($is_admin): ?>
          <a class="btn btn-warning btn-sm" href="admin/dashboard.php">Admin</a>
        <?php endif; ?>
        <a class="btn btn-outline-light btn-sm" href="sell.php">Sell</a>
        <a class="btn btn-outline-light btn-sm position-relative" href="cart.php" title="Cart">
          Cart
          <span class="cart-count cart-badge ms-2"><?php echo intval($cart_count); ?></span>
        </a>
        <a class="btn btn-danger btn-sm" href="logout.php">Logout</a>
      <?php else: ?>
        <a class="btn btn-outline-light btn-sm" href="login.php">Login</a>
      <?php endif; ?>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <div class="d-flex justify-content-between align-items-center mb-3 gap-3">
    <h3 class="mb-0">Marketplace</h3>

    <form class="input-search" method="get" style="max-width:520px; width:100%;">
      <input type="text" name="q" placeholder="Search title or description..." value="<?php echo htmlspecialchars($search); ?>">
      <?php if($search !== ''): ?>
        <a class="btn btn-outline-secondary" href="marketplace.php" title="Clear">Clear</a>
      <?php endif; ?>
      <button class="btn btn-primary" type="submit">Search</button>
    </form>
  </div>

  <?php if($total == 0): ?>
    <div class="card p-3 mb-3">
      <p class="mb-0">No listings found<?php echo ($search !== '') ? ' for "' . htmlspecialchars($search) . '"' : ''; ?>. Try a different search or <a href="sell.php">post an item</a>.</p>
    </div>
  <?php else: ?>

  <div class="marketplace-grid mb-3">
    <?php while($row = $result->fetch_assoc()): ?>
      <div class="marketplace-card card position-relative">
        <?php
          $imgPath = !empty($row['image']) && file_exists(__DIR__ . '/uploads/' . $row['image']) ? 'uploads/' . rawurlencode($row['image']) : '';
        ?>
        <?php if($imgPath): ?>
          <img src="<?php echo $imgPath; ?>" alt="" class="product-thumb">
        <?php else: ?>
          <div style="height:180px; display:flex; align-items:center; justify-content:center; background:#fff7f8; color:#c44; font-weight:600; border-radius:12px 12px 0 0;">
            No image
          </div>
        <?php endif; ?>

        <div class="card-body">
          <h5><?php echo htmlspecialchars($row['title']); ?></h5>
          <p class="price mb-1">RM <?php echo number_format($row['price'],2); ?></p>
          <p class="description truncate-3 text-muted mb-2"><?php echo nl2br(htmlspecialchars($row['description'])); ?></p>
          <p class="seller small text-muted mb-2">Seller: <?php echo htmlspecialchars($row['name'] ?: 'Unknown'); ?></p>
          <p class="small text-muted mb-2">Status: <?php echo htmlspecialchars($row['status']); ?></p>

          <div class="d-flex gap-2">
            <button class="btn btn-outline-primary btn-sm view-btn"
              type="button"
              data-bs-toggle="modal" data-bs-target="#viewModal"
              data-title="<?php echo htmlspecialchars($row['title']); ?>"
              data-desc="<?php echo htmlspecialchars($row['description']); ?>"
              data-price="<?php echo number_format($row['price'],2); ?>"
              data-seller="<?php echo htmlspecialchars($row['name'] ?: 'Unknown'); ?>"
              data-contact="<?php echo htmlspecialchars($row['contact'] ?? ''); ?>"
              data-image="<?php echo $imgPath; ?>"
            >View</button>

            <?php if(isset($_SESSION['user_id']) && intval($_SESSION['user_id']) === intval($row['user_id'])): ?>
              <a class="btn btn-outline-secondary btn-sm" href="edit_my_listing.php?id=<?php echo intval($row['id']); ?>">Edit</a>
            <?php endif; ?>

            <?php if(isset($_SESSION['user_id'])): ?>
              <button class="btn btn-sm btn-success add-to-cart-btn" data-id="<?php echo intval($row['id']); ?>" data-qty="1" type="button">Add to cart</button>
            <?php else: ?>
              <a class="btn btn-sm btn-success" href="login.php">Add to cart</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  </div>

  <nav aria-label="Page navigation">
    <ul class="pagination justify-content-center">
      <li class="page-item <?php if($page <= 1) echo 'disabled'; ?>">
        <a class="page-link" href="?q=<?php echo urlencode($search); ?>&p=<?php echo $page - 1; ?>">Previous</a>
      </li>
      <?php
      $start = max(1, $page - 2);
      $end = min($totalPages, $page + 2);
      if($start > 1) {
        echo '<li class="page-item"><a class="page-link" href="?q='.urlencode($search).'&p=1">1</a></li>';
        if($start > 2) echo '<li class="page-item disabled"><span class="page-link">…</span></li>';
      }
      for($i = $start; $i <= $end; $i++): ?>
        <li class="page-item <?php if($i == $page) echo 'active'; ?>">
          <a class="page-link" href="?q=<?php echo urlencode($search); ?>&p=<?php echo $i; ?>"><?php echo $i; ?></a>
        </li>
      <?php endfor;
      if($end < $totalPages) {
        if($end < $totalPages - 1) echo '<li class="page-item disabled"><span class="page-link">…</span></li>';
        echo '<li class="page-item"><a class="page-link" href="?q='.urlencode($search).'&p='.$totalPages.'">'.$totalPages.'</a></li>';
      }
      ?>
      <li class="page-item <?php if($page >= $totalPages) echo 'disabled'; ?>">
        <a class="page-link" href="?q=<?php echo urlencode($search); ?>&p=<?php echo $page + 1; ?>">Next</a>
      </li>
    </ul>
  </nav>

  <?php endif; ?>

</div>

<div class="modal fade" id="viewModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="viewModalLabel">Item</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body d-flex flex-column gap-3">
        <div class="row g-3">
          <div class="col-md-6" id="modalImageWrap" style="display:flex;align-items:center;justify-content:center;">
            <img id="modalImage" src="" alt="" class="img-fluid" style="max-height:320px; object-fit:cover; border-radius:12px;">
          </div>
          <div class="col-md-6">
            <h5 id="modalTitle"></h5>
            <p class="text-muted mb-1">Price: <strong id="modalPrice"></strong></p>
            <p class="text-muted mb-1">Seller: <span id="modalSeller"></span></p>
            <hr>
            <div id="modalDesc" class="small text-muted mb-2"></div>
            <div id="modalContact" class="small text-muted"></div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <a id="modalAddToCart" class="btn btn-success d-none">Add to cart</a>
      </div>
    </div>
  </div>
</div>

<script src="assets/js/cart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('click', function(e){
  var btn = e.target.closest('.view-btn');
  if(!btn) return;
  var title = btn.getAttribute('data-title') || '';
  var desc = btn.getAttribute('data-desc') || '';
  var price = btn.getAttribute('data-price') || '';
  var seller = btn.getAttribute('data-seller') || '';
  var contact = btn.getAttribute('data-contact') || '';
  var image = btn.getAttribute('data-image') || '';

  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalDesc').textContent = desc;
  document.getElementById('modalPrice').textContent = 'RM ' + price;
  document.getElementById('modalSeller').textContent = seller;
  document.getElementById('modalContact').textContent = contact ? ('Contact: ' + contact) : '';

  var imgEl = document.getElementById('modalImage');
  if(image) {
    imgEl.src = image;
    imgEl.style.display = 'block';
  } else {
    imgEl.style.display = 'none';
  }
});
</script>
</body>
</html>