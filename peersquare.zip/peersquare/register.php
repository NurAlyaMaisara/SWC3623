<?php
session_start();
include 'db_connect.php';

$errors = [];
$name_val = '';
$email_val = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    // keep values so form can be re-populated on error
    $name_val = $name;
    $email_val = $email;

    if($name === '') $errors[] = "Name is required.";
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email.";
    if(strlen($password) < 6) $errors[] = "Password must be at least 6 characters.";

    if(empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        // check existing email first
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $checkRes = $check->get_result();
        if($checkRes && $checkRes->num_rows > 0) {
            $errors[] = "An account with that email already exists.";
            $check->close();
        } else {
            $check->close();
            $stmt = $conn->prepare("INSERT INTO users (name,email,password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $email, $hash);
            if($stmt->execute()) {
                // use connection insert_id (more reliable)
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['role'] = 'user';
                header("Location: index.php");
                exit;
            } else {
                $errors[] = "Failed to create account. Please try again.";
            }
            $stmt->close();
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Create account | PeerSquare</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    .auth-card { max-width: 920px; margin: 40px auto; border-radius: 14px; overflow: hidden; }
    .auth-left {
      background: linear-gradient(180deg, rgba(255,75,92,0.06), rgba(255,106,136,0.03));
      padding: 28px;
      display:flex;
      flex-direction:column;
      justify-content:center;
      align-items:center;
      min-height: 320px;
    }
    .brand-mark {
      width:84px; height:84px; border-radius:12px; background:#fff; display:flex; align-items:center; justify-content:center; box-shadow: 0 8px 24px rgba(0,0,0,0.06);
    }
    .brand-mark img { height:44px; }
    .auth-right { padding:28px; }
    .form-footer { display:flex; justify-content:space-between; align-items:center; gap:12px; }
    .password-toggle { cursor:pointer; color:var(--primary); font-weight:600; }
    .spinner-border-sm { width:1rem; height:1rem; border-width: .12rem; }
    @media (max-width: 767px) {
      .auth-left { padding:18px; min-height:160px; }
      .auth-card { margin: 18px; }
    }
  </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-dark">
  <div class="container d-flex justify-content-between align-items-center">
    <!-- logo: image only -->
    <a class="navbar-brand d-flex align-items-center" href="index.php" aria-label="PeerSquare" title="PeerSquare">
      <img src="assets/images/P.png" alt="PeerSquare" style="height:38px; margin-right:8px;">
    </a>
    <div class="d-flex align-items-center">
      <a href="marketplace.php" class="nav-link px-3 text-white">Marketplace</a>
      <a href="login.php" class="btn btn-outline-light btn-sm mx-1">Login</a>
    </div>
  </div>
</nav>

<div class="container">
  <div class="card auth-card shadow-sm">
    <div class="row g-0">
      <div class="col-md-5 auth-left text-center">
        <div class="brand-mark mb-3">
          <img src="assets/images/P.png" alt="PeerSquare">
        </div>
        <h4 class="kicker">Create your account</h4>
        <p class="text-muted" style="max-width:220px;">Join the student marketplace to buy, sell, and report lost & found items.</p>
        <div class="mt-3">
          <a href="marketplace.php" class="btn btn-outline-secondary btn-sm">Browse marketplace</a>
        </div>
      </div>

      <div class="col-md-7 auth-right">
        <h4 class="mb-3">Register</h4>

        <?php if(!empty($errors)): ?>
          <?php foreach($errors as $e): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($e); ?></div>
          <?php endforeach; ?>
        <?php endif; ?>

        <form id="registerForm" method="post" action="register.php" novalidate>
          <div class="mb-3">
            <label class="form-label">Full name</label>
            <input class="form-control" name="name" placeholder="Your name" required value="<?php echo htmlspecialchars($name_val); ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control" name="email" type="email" placeholder="you@example.com" required value="<?php echo htmlspecialchars($email_val); ?>">
          </div>

          <div class="mb-3 position-relative">
            <label class="form-label">Password</label>
            <div class="input-group">
              <input id="password" class="form-control" name="password" type="password" placeholder="Choose a password" required>
              <button id="togglePwd" class="btn btn-outline-secondary" type="button" title="Show / hide password">Show</button>
            </div>
            <div class="hint mt-2">Use at least 6 characters. Include more for a stronger password.</div>
          </div>

          <div class="d-flex gap-2">
            <button id="registerBtn" class="btn btn-primary w-100" type="submit">
              <span id="btnText">Create account</span>
              <span id="btnSpinner" class="spinner-border spinner-border-sm ms-2" role="status" aria-hidden="true" style="display:none;"></span>
            </button>
          </div>

          <div class="mt-3 text-center small text-muted">
            Already have an account? <a href="login.php">Login</a>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>

<footer class="footer" style="position:fixed;bottom:0;left:0;right:0;">
  PeerSquare — Student Marketplace
</footer>

<script>
(function(){
  // Toggle password visibility
  var pwd = document.getElementById('password');
  var toggle = document.getElementById('togglePwd');
  toggle.addEventListener('click', function(){
    if(pwd.type === 'password'){ pwd.type = 'text'; toggle.textContent = 'Hide'; }
    else { pwd.type = 'password'; toggle.textContent = 'Show'; }
    pwd.focus();
  });

  // Disable double-submit and show spinner
  var form = document.getElementById('registerForm');
  var btn = document.getElementById('registerBtn');
  var btnText = document.getElementById('btnText');
  var btnSpinner = document.getElementById('btnSpinner');
  form.addEventListener('submit', function(e){
    // basic client-side validation
    var name = form.querySelector('[name=name]').value.trim();
    var email = form.querySelector('[name=email]').value.trim();
    var password = form.querySelector('[name=password]').value;
    if(!name) {
      alert('Please enter your full name.');
      e.preventDefault();
      return false;
    }
    if(!email) {
      alert('Please enter a valid email.');
      e.preventDefault();
      return false;
    }
    if(!password || password.length < 6) {
      alert('Please choose a password with at least 6 characters.');
      e.preventDefault();
      return false;
    }
    // show spinner and prevent multiple submits
    btn.disabled = true;
    btnSpinner.style.display = 'inline-block';
    btnText.textContent = 'Creating...';
  });
})();
</script>

</body>
</html>