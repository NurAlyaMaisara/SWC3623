// assets/js/cart.js
// Lightweight helper: send add-to-cart via fetch and update a cart-count element (if present).
document.addEventListener('click', function(e){
  var btn = e.target.closest('.add-to-cart-btn');
  if(!btn) return;
  e.preventDefault();
  var id = btn.getAttribute('data-id');
  var qty = btn.getAttribute('data-qty') || 1;
  if(!id) return;

  // UI feedback: disable while processing
  btn.dataset.origText = btn.textContent;
  btn.classList.add('disabled');
  btn.textContent = 'Adding...';

  fetch('cart_add.php', {
    method: 'POST',
    headers: {'Accept': 'application/json'},
    body: (function(){
      var fd = new FormData();
      fd.append('listing_id', id);
      fd.append('quantity', qty);
      return fd;
    })()
  })
  .then(function(res){
    if(res.status === 401) {
      // not logged in -> redirect to login
      window.location.href = 'login.php';
      throw new Error('login_required');
    }
    return res.json();
  })
  .then(function(json){
    btn.classList.remove('disabled');
    if(json && json.ok) {
      // update cart count if element exists
      var el = document.querySelector('.cart-count');
      if(el) el.textContent = json.cart_count || '';
      // brief feedback
      btn.textContent = 'Added';
      setTimeout(function(){ btn.textContent = btn.dataset.origText || 'Add to cart'; }, 1200);
    } else {
      var msg = (json && json.error) ? json.error : 'Failed';
      alert('Add to cart failed: ' + msg);
      btn.textContent = btn.dataset.origText || 'Add to cart';
    }
  })
  .catch(function(err){
    if(err.message === 'login_required') return;
    btn.classList.remove('disabled');
    btn.textContent = btn.dataset.origText || 'Add to cart';
    if(err && err.message !== 'login_required') {
      console.error(err);
      alert('Network error adding to cart.');
    }
  });
});