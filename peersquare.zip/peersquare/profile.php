<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include 'db_connect.php';
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
$user_id = intval($_SESSION['user_id']);

$success = $error = "";

// Handle listing deletion
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_listing') {
    $delete_id = intval($_POST['delete_listing_id'] ?? 0);
    if($delete_id <= 0) {
        $error = "Invalid listing selected.";
    } else {
        $chk = $conn->prepare("SELECT image, user_id FROM marketplace WHERE id = ?");
        $chk->bind_param("i", $delete_id);
        $chk->execute();
        $row = $chk->get_result()->fetch_assoc();
        $chk->close();
        if(!$row) {
            $error = "Listing not found.";
        } elseif(intval($row['user_id']) !== $user_id) {
            $error = "You don't have permission to delete this listing.";
        } else {
            if(!empty($row['image'])) {
                $file = __DIR__ . '/uploads/' . $row['image'];
                if(file_exists($file)) @unlink($file);
            }
            $del = $conn->prepare("DELETE FROM marketplace WHERE id = ?");
            $del->bind_param("i", $delete_id);
            if($del->execute()) {
                $success = "Listing deleted.";
            } else {
                $error = "Failed to delete listing. Please try again.";
            }
            $del->close();
        }
    }
}

// Handle profile update
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $name = trim($_POST['name']);
    $email = strtolower(trim($_POST['email']));
    $newpass = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address.";
    } elseif($newpass !== "" && strlen($newpass) < 6) {
        $error = "New password must be at least 6 characters.";
    } elseif($newpass !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        if($newpass !== "") {
            $hash = password_hash($newpass, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET name=?, email=?, password=? WHERE id=?");
            $stmt->bind_param("sssi", $name, $email, $hash, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET name=?, email=? WHERE id=?");
            $stmt->bind_param("ssi", $name, $email, $user_id);
        }
        if($stmt->execute()) {
            $success = "Profile updated.";
        } else {
            $error = "Failed to update profile. Email may already be in use.";
        }
        $stmt->close();
    }
}

// Handle account deletion (requires current password confirmation)
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_account') {
    $pw = $_POST['confirm_password'] ?? '';

    $pwStmt = $conn->prepare("SELECT password, role FROM users WHERE id = ?");
    $pwStmt->bind_param("i", $user_id);
    $pwStmt->execute();
    $pwRow = $pwStmt->get_result()->fetch_assoc();
    $pwStmt->close();

    if(!$pwRow) {
        $error = "User record not found.";
    } elseif(empty($pw)) {
        $error = "Please enter your password to confirm account deletion.";
    } elseif(!password_verify($pw, $pwRow['password'])) {
        $error = "Password incorrect. Account not deleted.";
    } else {
        // 1) Delete marketplace images/files
        $mq = $conn->prepare("SELECT image FROM marketplace WHERE user_id = ?");
        $mq->bind_param("i", $user_id);
        $mq->execute();
        $mqRes = $mq->get_result();
        while($r = $mqRes->fetch_assoc()){
            if(!empty($r['image'])) {
                $file = __DIR__ . '/uploads/' . $r['image'];
                if(file_exists($file)) @unlink($file);
            }
        }
        $mq->close();

        // 2) Delete lostfound images/files
        $lq = $conn->prepare("SELECT image FROM lostfound WHERE user_id = ?");
        $lq->bind_param("i", $user_id);
        $lq->execute();
        $lqRes = $lq->get_result();
        while($r = $lqRes->fetch_assoc()){
            if(!empty($r['image'])) {
                $file = __DIR__ . '/uploads/' . $r['image'];
                if(file_exists($file)) @unlink($file);
            }
        }
        $lq->close();

        // 3) Delete marketplace rows
        $d1 = $conn->prepare("DELETE FROM marketplace WHERE user_id = ?");
        $d1->bind_param("i", $user_id);
        $d1->execute();
        $d1->close();

        // 4) Delete lostfound rows
        $d2 = $conn->prepare("DELETE FROM lostfound WHERE user_id = ?");
        $d2->bind_param("i", $user_id);
        $d2->execute();
        $d2->close();

        // 5) Finally delete user record
        $dUser = $conn->prepare("DELETE FROM users WHERE id = ?");
        $dUser->bind_param("i", $user_id);
        if($dUser->execute()){
            $dUser->close();
            session_unset();
            session_destroy();
            header("Location: index.php?msg=account_deleted");
            exit;
        } else {
            $error = "Failed to delete account. Please contact support.";
            $dUser->close();
        }
    }
}

$stmt = $conn->prepare("SELECT id,name,email,role,created_at FROM users WHERE id = ?");
$stmt->bind_param("i",$user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$totListings = $conn->prepare("SELECT COUNT(*) AS c FROM marketplace WHERE user_id = ?");
$totListings->bind_param("i", $user_id);
$totListings->execute();
$totListingsCount = $totListings->get_result()->fetch_assoc()['c'];
$totListings->close();

$totReports = $conn->prepare("SELECT COUNT(*) AS c FROM lostfound WHERE user_id = ?");
$totReports->bind_param("i", $user_id);
$totReports->execute();
$totReportsCount = $totReports->get_result()->fetch_assoc()['c'];
$totReports->close();

$mlStmt = $conn->prepare("SELECT id,title,price,image,status,created_at FROM marketplace WHERE user_id = ? ORDER BY created_at DESC LIMIT 6");
$mlStmt->bind_param("i", $user_id);
$mlStmt->execute();
$myListings = $mlStmt->get_result();
$mlStmt->close();

$lfStmt = $conn->prepare("SELECT id,item_name,category,status,image,created_at FROM lostfound WHERE user_id = ? ORDER BY created_at DESC LIMIT 6");
$lfStmt->bind_param("i", $user_id);
$lfStmt->execute();
$myReports = $lfStmt->get_result();
$lfStmt->close();

// ONLY show orders where status is not deleted/canceled
$ordersStmt = $conn->prepare("SELECT id, total_amount, status, payment_method, created_at FROM orders WHERE user_id = ? AND status NOT IN ('deleted','canceled') ORDER BY created_at DESC LIMIT 12");
$ordersStmt->bind_param("i", $user_id);
$ordersStmt->execute();
$myOrders = $ordersStmt->get_result();
$ordersStmt->close();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Profile - PeerSquare</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    .profile-avatar { width:110px;height:110px;border-radius:16px;background: linear-gradient(180deg,#fff,#fff);display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--primary-600);font-size:32px;box-shadow: var(--shadow-light);}
    .stat-pill { background: #fff7f8; border-radius:10px; padding:10px 12px; text-align:center; box-shadow: 0 6px 18px rgba(0,0,0,0.04); }
    .section-title { color: var(--primary); font-weight:700; }
    .card .card-body { padding:14px; }
    .small-thumb { width:100%; height:120px; object-fit:cover; border-radius:10px; }
    .empty-thumb { height:120px; display:flex; align-items:center; justify-content:center; background:#fff7f8; color:#c44; border-radius:10px; font-weight:700; }
    .tab-btns .btn { min-width:120px; }
    @media (max-width: 768px) { .profile-avatar { width:90px; height:90px; font-size:24px; } }
  </style>
</head>
<body>
<nav class="navbar navbar-dark">
  <div class="container d-flex justify-content-between align-items-center">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
      <img src="assets/images/P.png" alt="PeerSquare" style="height:45px; margin-right:8px;">
    </a>
    <div class="d-flex align-items-center">
      <a href="marketplace.php" class="nav-link px-3 text-white">Marketplace</a>
      <a href="sell.php" class="nav-link px-3 text-white">Sell</a>
      <a href="lostfound.php" class="nav-link px-3 text-white">Lost & Found</a>
      <a class="btn btn-danger btn-sm mx-1" href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <?php if($success): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
  <?php if($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
  <div class="row gy-3">
    <div class="col-md-4">
      <div class="card profile-card p-3">
        <div class="d-flex gap-3 align-items-center">
          <div class="profile-avatar">
            <?php
              $initials = 'U';
              if(!empty($user['name'])) {
                $parts = preg_split('/\s+/', $user['name']);
                $initials = strtoupper(mb_substr($parts[0],0,1,'UTF-8') . (isset($parts[1]) ? mb_substr($parts[1],0,1,'UTF-8') : ''));
              }
              echo htmlspecialchars($initials);
            ?>
          </div>
          <div>
            <h4 style="margin-bottom:4px;"><?php echo htmlspecialchars($user['name']); ?></h4>
            <div class="text-muted small"><?php echo htmlspecialchars($user['email']); ?></div>
            <div class="text-muted small">Role: <?php echo htmlspecialchars($user['role']); ?> &middot; Joined: <?php echo htmlspecialchars(date('M j, Y', strtotime($user['created_at']))); ?></div>
          </div>
        </div>
        <div class="row mt-3">
          <div class="col-6">
            <div class="stat-pill">
              <div class="kicker">Listings</div>
              <div style="font-size:18px; font-weight:700;"><?php echo intval($totListingsCount); ?></div>
            </div>
          </div>
          <div class="col-6">
            <div class="stat-pill">
              <div class="kicker">Reports</div>
              <div style="font-size:18px; font-weight:700;"><?php echo intval($totReportsCount); ?></div>
            </div>
          </div>
        </div>
        <div class="mt-3 d-flex gap-2">
          <button class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#editProfileForm">Edit Profile</button>
          <a href="sell.php" class="btn btn-outline-primary">Post Listing</a>
        </div>
        <div class="mt-3">
          <button class="btn btn-outline-danger w-100" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">Delete my account</button>
        </div>
        <div class="collapse mt-3" id="editProfileForm">
          <form method="post" class="mt-2">
            <input type="hidden" name="action" value="update_profile">
            <div class="mb-2">
              <label class="form-label">Full name</label>
              <input class="form-control" name="name" required value="<?php echo htmlspecialchars($user['name']); ?>">
            </div>
            <div class="mb-2">
              <label class="form-label">Email</label>
              <input class="form-control" name="email" type="email" required value="<?php echo htmlspecialchars($user['email']); ?>">
            </div>
            <hr>
            <div class="mb-2">
              <label class="form-label">New password (optional)</label>
              <input class="form-control" name="new_password" type="password" placeholder="Leave blank to keep current">
            </div>
            <div class="mb-2">
              <input class="form-control" name="confirm_password" type="password" placeholder="Confirm new password">
            </div>
            <div class="d-flex gap-2">
              <button class="btn btn-success">Save</button>
              <button class="btn btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#editProfileForm">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="col-md-8">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0 section-title">Your Activity</h3>
        <div class="tab-btns btn-group" role="group" aria-label="Tabs">
          <button class="btn btn-outline-primary active" id="tabListingsBtn">Listings</button>
          <button class="btn btn-outline-primary" id="tabReportsBtn">Reports</button>
          <button class="btn btn-outline-primary" id="tabOrdersBtn">Orders</button>
        </div>
      </div>
      <div id="tabListings" class="mb-3">
        <div class="row gx-3 gy-3">
          <?php if($myListings->num_rows == 0): ?>
            <div class="col-12">
              <div class="card p-3">
                <p class="mb-0">You have no listings yet. <a href="sell.php">Post an item</a>.</p>
              </div>
            </div>
          <?php else: ?>
            <?php while($l = $myListings->fetch_assoc()): ?>
              <div class="col-md-6 col-lg-4">
                <div class="card marketplace-card">
                  <?php if(!empty($l['image']) && file_exists(__DIR__ . '/uploads/' . $l['image'])): ?>
                    <img src="uploads/<?php echo rawurlencode($l['image']); ?>" class="product mb-0" alt="">
                  <?php else: ?>
                    <div class="empty-thumb mb-0">No image</div>
                  <?php endif; ?>
                  <div class="card-body">
                    <h5><?php echo htmlspecialchars($l['title']); ?></h5>
                    <p class="price mb-1">RM <?php echo number_format($l['price'],2); ?></p>
                    <p class="small text-muted mb-2">Status: <?php echo htmlspecialchars($l['status']); ?></p>
                    <div class="d-flex gap-2">
                      <a class="btn btn-outline-primary btn-sm" href="marketplace.php?q=<?php echo urlencode($l['title']); ?>">View</a>
                      <a class="btn btn-outline-secondary btn-sm" href="edit_my_listing.php?id=<?php echo intval($l['id']); ?>">Edit</a>
                      <form method="post" style="display:inline-block;" onsubmit="return confirm('Delete this listing? This action cannot be undone.');">
                        <input type="hidden" name="action" value="delete_listing">
                        <input type="hidden" name="delete_listing_id" value="<?php echo intval($l['id']); ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            <?php endwhile; ?>
          <?php endif; ?>
        </div>
      </div>
      <div id="tabReports" style="display:none;" class="mb-3">
        <div class="row gx-3 gy-3">
          <?php if($myReports->num_rows == 0): ?>
            <div class="col-12">
              <div class="card p-3">
                <p class="mb-0">No lost & found reports yet. <a href="lostfound.php">Report an item</a>.</p>
              </div>
            </div>
          <?php else: ?>
            <?php while($r = $myReports->fetch_assoc()): ?>
              <div class="col-md-6 col-lg-4">
                <div class="card">
                  <?php if(!empty($r['image']) && file_exists(__DIR__ . '/uploads/' . $r['image'])): ?>
                    <img src="uploads/<?php echo rawurlencode($r['image']); ?>" class="small-thumb" alt="">
                  <?php else: ?>
                    <div class="empty-thumb">No image</div>
                  <?php endif; ?>
                  <div class="card-body">
                    <h5><?php echo htmlspecialchars($r['item_name']); ?></h5>
                    <p class="small text-muted mb-1"><?php echo htmlspecialchars($r['category']); ?> &middot; <?php echo htmlspecialchars(ucfirst($r['status'])); ?></p>
                    <p class="small text-muted mb-2"><?php echo htmlspecialchars(date('M j, Y', strtotime($r['created_at']))); ?></p>
                    <div class="d-flex gap-2">
                      <a class="btn btn-outline-primary btn-sm" href="lostfound.php?q=<?php echo urlencode($r['item_name']); ?>">View</a>
                      <a class="btn btn-outline-secondary btn-sm" href="edit_my_report.php?id=<?php echo intval($r['id']); ?>">Edit</a>
                    </div>
                  </div>
                </div>
              </div>
            <?php endwhile; ?>
          <?php endif; ?>
        </div>
      </div>
      <div id="tabOrders" style="display:none;" class="mb-3">
        <div class="row gx-3 gy-3">
          <?php if($myOrders->num_rows == 0): ?>
            <div class="col-12">
              <div class="card p-3">
                <p class="mb-0">You have no orders yet.</p>
              </div>
            </div>
          <?php else: ?>
            <?php while($o = $myOrders->fetch_assoc()): ?>
            <div class="col-12">
              <div class="card order-card-<?php echo intval($o['id']); ?>">
                <div class="card-body">
                  <h5>Order #<?php echo intval($o['id']); ?></h5>
                  <p class="mb-1">Total: RM <?php echo number_format($o['total_amount'], 2); ?></p>
                  <p class="small mb-1">
                    Status: <span class="order-status-<?php echo intval($o['id']); ?>"><?php echo htmlspecialchars(ucfirst($o['status'])); ?></span>
                    &middot; Payment: <?php echo htmlspecialchars(str_replace('_',' ', $o['payment_method'])); ?>
                  </p>
                  <p class="small text-muted mb-0">
                    Placed: <?php echo htmlspecialchars(date('M j, Y H:i', strtotime($o['created_at']))); ?>
                  </p>

                  <div class="mt-2 d-flex gap-2">
                    <!-- View order summary -->
                    <a class="btn btn-outline-primary btn-sm" href="order_success.php?id=<?php echo intval($o['id']); ?>">View</a>

                    <?php
                      // Determine if order is cancellable: pending_payment or pending (or no payment method set)
                      $status_l = strtolower($o['status']);
                      $payment_m = trim((string)($o['payment_method'] ?? ''));
                      $cancellable = in_array($status_l, ['pending_payment','pending'], true) || ($payment_m === '');
                    ?>

                    <?php if($cancellable): ?>
                      <button class="btn btn-warning btn-sm cancel-order-btn" data-id="<?php echo intval($o['id']); ?>">Cancel</button>
                    <?php endif; ?>

                    <!-- Note: per request, completed/paid/shipped orders only show View (no Delete button) -->
                  </div>
                </div>
              </div>
            </div>
            <?php endwhile; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="deleteAccountModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="post" class="p-0">
        <input type="hidden" name="action" value="delete_account">
        <div class="modal-header">
          <h5 class="modal-title">Delete account</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p class="text-danger">Warning: deleting your account is permanent. This will remove your listings, reports and your account. This cannot be undone.</p>
          <div class="mb-2">
            <label class="form-label">Confirm with your password</label>
            <input type="password" name="confirm_password" class="form-control" required placeholder="Enter your password to delete account">
          </div>
          <?php if($error && isset($_POST['action']) && $_POST['action'] === 'delete_account'): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
          <?php endif; ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-danger">Delete my account</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Tab switching
document.getElementById('tabListingsBtn').addEventListener('click', function(){
  document.getElementById('tabListings').style.display = '';
  document.getElementById('tabReports').style.display = 'none';
  document.getElementById('tabOrders').style.display = 'none';
  this.classList.add('active');
  document.getElementById('tabReportsBtn').classList.remove('active');
  document.getElementById('tabOrdersBtn').classList.remove('active');
});
document.getElementById('tabReportsBtn').addEventListener('click', function(){
  document.getElementById('tabReports').style.display = '';
  document.getElementById('tabListings').style.display = 'none';
  document.getElementById('tabOrders').style.display = 'none';
  this.classList.add('active');
  document.getElementById('tabListingsBtn').classList.remove('active');
  document.getElementById('tabOrdersBtn').classList.remove('active');
});
document.getElementById('tabOrdersBtn').addEventListener('click', function(){
  document.getElementById('tabOrders').style.display = '';
  document.getElementById('tabListings').style.display = 'none';
  document.getElementById('tabReports').style.display = 'none';
  this.classList.add('active');
  document.getElementById('tabListingsBtn').classList.remove('active');
  document.getElementById('tabReportsBtn').classList.remove('active');
});

// AJAX Cancel
document.addEventListener('click', function(e){
  var cbtn = e.target.closest('.cancel-order-btn');
  if(cbtn) {
    e.preventDefault();
    var id = cbtn.getAttribute('data-id');
    if(!confirm('Cancel this order? If payment was already completed this may not be allowed.')) return;
    cbtn.classList.add('disabled');
    cbtn.textContent = 'Canceling...';
    fetch('order_cancel.php', {
      method: 'POST',
      headers: {'Accept':'application/json'},
      body: (() => { var fd = new FormData(); fd.append('order_id', id); return fd; })()
    })
    .then(res => res.json())
    .then(json => {
      cbtn.classList.remove('disabled');
      if(json && json.ok) {
        // remove order card from DOM
        var orderCard = document.querySelector('.order-card-' + id);
        if(orderCard) orderCard.remove();
      } else {
        cbtn.textContent = 'Cancel';
        alert(json.error || 'Failed to cancel order.');
      }
    })
    .catch(() => {
      cbtn.classList.remove('disabled');
      cbtn.textContent = 'Cancel';
      alert('Network error canceling order.');
    });
    return;
  }
});
</script>
</body>
</html>