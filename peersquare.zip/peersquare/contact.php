<?php
session_start();
include 'db_connect.php'; 

$adminEmail = 'support@example.com'; 
$success = $error = "";

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if($name === '' || $email === '' || $message === '') {
        $error = "Please fill in all fields.";
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        // attempt to store in DB if $conn is available
        $stored = false;
        if(isset($conn) && $conn instanceof mysqli) {
            $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;
            $ip = $_SERVER['REMOTE_ADDR'] ?? null;
            $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);

            $stmt = $conn->prepare("INSERT INTO contact_messages (user_id, name, email, message, ip, user_agent) VALUES (?, ?, ?, ?, ?, ?)");
            if($stmt) {
                // bind user_id as integer or null
                if($user_id === null) {
                    // bind_param requires a value; use NULL via types and variable
                    $null = null;
                    $stmt->bind_param("isssss", $null, $name, $email, $message, $ip, $ua);
                } else {
                    $stmt->bind_param("isssss", $user_id, $name, $email, $message, $ip, $ua);
                }
                if($stmt->execute()) {
                    $stored = true;
                }
                $stmt->close();
            }
        }

        // Always attempt to mail (may fail on local dev). Build message body.
        $subject = "Contact form: PeerSquare message from " . $name;
        $body = "From: {$name}\nEmail: {$email}\n\nMessage:\n" . $message;
        $headers = "From: {$email}\r\nReply-To: {$email}\r\n";

        $mailed = false;
        if(@mail($adminEmail, $subject, $body, $headers)) {
            $mailed = true;
        }

        // If mail not available or DB store failed, keep a file fallback (still useful)
        if(!$stored || !$mailed) {
            $logLine = "[" . date('Y-m-d H:i:s') . "] ";
            if(isset($_SESSION['user_id'])) $logLine .= "UID:" . intval($_SESSION['user_id']) . " ";
            $logLine .= "From: {$name} <{$email}> IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . " UA: " . substr($_SERVER['HTTP_USER_AGENT'] ?? '',0,80) . " Message: " . str_replace(["\r","\n"], [' ', ' '], substr($message,0,1000)) . PHP_EOL;
            @file_put_contents(__DIR__ . '/data/contact_messages.log', $logLine, FILE_APPEND | LOCK_EX);
        }

        // Show success message (even if mail failed — stored in DB or log)
        $success = "Thanks — your message has been received. We'll get back to you soon.";
        // clear form fields
        $name = $email = $message = '';
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Contact — PeerSquare</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php"><img src="assets/images/P.png" alt="PeerSquare" style="height:42px;"></a>
    <div class="ms-auto">
      <a class="nav-link d-inline text-white" href="marketplace.php">Marketplace</a>
      <a class="nav-link d-inline text-white ms-2" href="lostfound.php">Lost &amp; Found</a>
      <a class="nav-link d-inline text-white ms-2" href="about.php">About</a>
    </div>
  </div>
</nav>

<div class="container my-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card p-4">
        <h3>Contact us</h3>
        <p class="text-muted">Questions, feedback or help — send us a message and we'll respond as soon as we can.</p>

        <?php if(!empty($success)): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
        <?php if(!empty($error)): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <form method="post">
          <div class="mb-2">
            <label class="form-label">Your name</label>
            <input class="form-control" name="name" required value="<?php echo htmlspecialchars($name ?? ''); ?>">
          </div>
          <div class="mb-2">
            <label class="form-label">Your email</label>
            <input class="form-control" name="email" type="email" required value="<?php echo htmlspecialchars($email ?? ''); ?>">
          </div>
          <div class="mb-2">
            <label class="form-label">Message</label>
            <textarea class="form-control" name="message" rows="6" required><?php echo htmlspecialchars($message ?? ''); ?></textarea>
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-primary">Send message</button>
            <a class="btn btn-outline-secondary" href="index.php">Back</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<footer class="footer py-3 bg-white" style="border-top:1px solid rgba(0,0,0,0.04);">
  <div class="container text-center small text-muted">&copy; <?php echo date('Y'); ?> PeerSquare</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>