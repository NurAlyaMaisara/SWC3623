<?php
session_start();
include 'db_connect.php';
header('Content-Type: application/json');
if(!isset($_SESSION['user_id'])) { echo json_encode(['ok'=>false,'error'=>'Please login']); exit(); }
$user_id = intval($_SESSION['user_id']);
$order_id = intval($_POST['order_id'] ?? 0);
if($order_id<=0) { echo json_encode(['ok'=>false,'error'=>'Invalid order']); exit(); }

// Only allow delete if order belongs to user and not already deleted
$q = $conn->prepare("SELECT status FROM orders WHERE id=? AND user_id=?");
$q->bind_param("ii", $order_id, $user_id);
$q->execute();
$row = $q->get_result()->fetch_assoc();
$q->close();
if(!$row) { echo json_encode(['ok'=>false,'error'=>'Order not found']); exit(); }
if($row['status']=='deleted') { echo json_encode(['ok'=>false,'error'=>'Order already deleted']); exit(); }
// Proceed to mark as deleted (soft delete)
$u = $conn->prepare("UPDATE orders SET status='deleted' WHERE id=? AND user_id=?");
$u->bind_param("ii", $order_id, $user_id);
if($u->execute()) {
    echo json_encode(['ok'=>true]);
} else {
    echo json_encode(['ok'=>false,'error'=>'Failed to delete order']);
}
$u->close();
?>