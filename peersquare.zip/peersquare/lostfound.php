<?php
session_start();
include 'db_connect.php';

$ok = $err = "";

// Only handle POST if user is logged in
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])){
    $item = trim($_POST['item_name']);
    $cat = trim($_POST['category']);
    $desc = trim($_POST['description']);
    $contact = trim($_POST['contact']);
    $user_id = $_SESSION['user_id'];
    $status = ($_POST['status'] === 'found') ? 'found' : 'lost';

    // Image upload
    $image_name = "";
    if(!empty($_FILES['image']['name'])) {
        $target_dir = "uploads/";
        if(!is_dir($target_dir)) mkdir($target_dir, 0755);
        $image_name = time() . "_" . basename($_FILES['image']['name']);
        $target_file = $target_dir . $image_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed = ["jpg","jpeg","png","gif","webp"];
        if(!in_array($imageFileType, $allowed)) {
            $err = "Only JPG, PNG, GIF and WEBP files are allowed.";
        } elseif(!getimagesize($_FILES['image']['tmp_name'])) {
            $err = "Uploaded file is not a valid image.";
        } else {
            if(!move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $err = "Failed to upload image.";
            }
        }
    }

    if(!$err) {
        $stmt = $conn->prepare("INSERT INTO lostfound (item_name, category, description, status, contact, user_id, image, created_at) VALUES (?,?,?,?,?,?,?,NOW())");
        $stmt->bind_param("sssssis", $item, $cat, $desc, $status, $contact, $user_id, $image_name);
        if($stmt->execute()) $ok = "Reported $status item successfully.";
        else $err = "Failed to report item.";
        $stmt->close();
    }
}

// search & pagination like marketplace
$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$perPage = 8;
$offset = ($page - 1) * $perPage;

if($search !== '') {
    $like = '%' . $search . '%';
    // count only non-deleted rows
    $countStmt = $conn->prepare("SELECT COUNT(*) AS c FROM lostfound l WHERE (l.item_name LIKE ? OR l.category LIKE ? OR l.description LIKE ?) AND l.status != 'deleted'");
    $countStmt->bind_param("sss", $like, $like, $like);
    $countStmt->execute();
    $total = $countStmt->get_result()->fetch_assoc()['c'];
    $countStmt->close();

    $stmt = $conn->prepare("SELECT l.*, u.name FROM lostfound l LEFT JOIN users u ON l.user_id=u.id WHERE (l.item_name LIKE ? OR l.category LIKE ? OR l.description LIKE ?) AND l.status != 'deleted' ORDER BY l.created_at DESC LIMIT ?, ?");
    $stmt->bind_param("sssii", $like, $like, $like, $offset, $perPage);
} else {
    // count only non-deleted rows
    $total = $conn->query("SELECT COUNT(*) AS c FROM lostfound WHERE status != 'deleted'")->fetch_assoc()['c'];
    $stmt = $conn->prepare("SELECT l.*, u.name FROM lostfound l LEFT JOIN users u ON l.user_id=u.id WHERE l.status != 'deleted' ORDER BY l.created_at DESC LIMIT ?, ?");
    $stmt->bind_param("ii", $offset, $perPage);
}

$stmt->execute();
$res = $stmt->get_result();
$totalPages = ($total > 0) ? ceil($total / $perPage) : 1;
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lost & Found</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<style>
/* page-specific tweaks to match marketplace layout */
.lostfound-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 18px; }
.item-thumb { height: 180px; object-fit: cover; width:100%; border-top-left-radius: 12px; border-top-right-radius: 12px; }
.card .card-body { padding: 12px; }
.truncate-3 { display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
.status-badge { position: absolute; top:12px; left:12px; padding:6px 10px; border-radius:10px; color:#fff; font-weight:700; }
.status-lost { background: #ff6a88; }
.status-found { background: #28a745; }
</style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php"><img src="assets/images/P.png" alt="PeerSquare" style="height:45px;"></a>
    <div class="ms-auto d-flex align-items-center">
      <?php if(isset($_SESSION['user_id'])): ?>
        <button class="btn btn-outline-light btn-sm me-2" data-bs-toggle="collapse" data-bs-target="#reportFormTop">Report</button>
        <a class="btn btn-danger btn-sm" href="logout.php">Logout</a>
      <?php else: ?>
        <a class="btn btn-outline-light btn-sm" href="login.php">Login</a>
      <?php endif; ?>
    </div>
  </div>
</nav>

<div class="container mt-4">

  <div class="d-flex justify-content-between align-items-center mb-3 gap-3">
    <h3 class="mb-0">Lost &amp; Found</h3>

    <form class="input-search" method="get" style="max-width:520px; width:100%;">
      <input type="text" name="q" placeholder="Search items, category, or description..." value="<?php echo htmlspecialchars($search); ?>">
      <?php if($search !== ''): ?>
        <a class="btn btn-outline-secondary" href="lostfound.php" title="Clear">Clear</a>
      <?php endif; ?>
      <button class="btn btn-primary" type="submit">Search</button>
    </form>
  </div>

  <!-- Report form (collapsible) -->
  <?php if(isset($_SESSION['user_id'])): ?>
  <div class="collapse mb-4" id="reportFormTop">
    <div class="card p-3">
      <h5>Report Lost or Found Item</h5>
      <?php if($ok): ?><div class="alert alert-success"><?= htmlspecialchars($ok) ?></div><?php endif;?>
      <?php if($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif;?>
      <form method="post" enctype="multipart/form-data">
          <div class="row g-2 mb-2">
              <div class="col-md-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="lost">Lost</option>
                    <option value="found">Found</option>
                </select>
              </div>
              <div class="col-md-9">
                <label class="form-label">Item name</label>
                <input class="form-control" name="item_name" placeholder="Item name" required>
              </div>
          </div>

          <div class="row g-2 mb-2">
            <div class="col-md-6">
              <input class="form-control" name="category" placeholder="Category">
            </div>
            <div class="col-md-6">
              <input class="form-control" name="contact" placeholder="Contact info (optional)">
            </div>
          </div>

          <div class="mb-2">
            <textarea class="form-control" name="description" placeholder="Description (include more details and contact if you wish)"></textarea>
          </div>

          <div class="mb-2">
            <label class="form-label">Upload Image (optional)</label>
            <input type="file" class="form-control" name="image" accept="image/*">
          </div>

          <button class="btn btn-success">Submit Report</button>
      </form>
    </div>
  </div>
  <?php else: ?>
    <div class="card p-3 mb-4">
      <p class="mb-0">Please <a href="login.php">log in</a> to report a lost or found item.</p>
    </div>
  <?php endif; ?>

  <?php if($total == 0): ?>
    <div class="card p-3 mb-3">
      <p class="mb-0">No reports found<?php echo ($search !== '') ? ' for "' . htmlspecialchars($search) . '"' : ''; ?>.</p>
    </div>
  <?php else: ?>

  <div class="lostfound-grid mb-3">
    <?php while($row = $res->fetch_assoc()): ?>
      <div class="card position-relative">
        <?php
          $imgPath = !empty($row['image']) && file_exists(__DIR__ . '/uploads/' . $row['image']) ? 'uploads/' . rawurlencode($row['image']) : '';
        ?>
        <span class="status-badge <?php echo ($row['status'] === 'found') ? 'status-found' : 'status-lost'; ?>">
          <?php echo htmlspecialchars(ucfirst($row['status'])); ?>
        </span>

        <?php if($imgPath): ?>
          <img src="<?php echo $imgPath; ?>" alt="" class="item-thumb">
        <?php else: ?>
          <div style="height:180px; display:flex; align-items:center; justify-content:center; background:#fff7f8; color:#c44; font-weight:600; border-top-left-radius:12px; border-top-right-radius:12px;">
            No image
          </div>
        <?php endif; ?>

        <div class="card-body">
          <h5><?php echo htmlspecialchars($row['item_name']); ?></h5>
          <p class="small text-muted mb-1"><?php echo htmlspecialchars($row['category']); ?> &middot; Reported: <?php echo htmlspecialchars(date('M j, Y', strtotime($row['created_at']))); ?></p>
          <p class="truncate-3 text-muted mb-2"><?php echo nl2br(htmlspecialchars($row['description'])); ?></p>
          <p class="seller small text-muted mb-2">Reported by: <?php echo htmlspecialchars($row['name'] ?: 'Unknown'); ?></p>

          <div class="d-flex gap-2">
            <button class="btn btn-outline-primary btn-sm view-btn"
              type="button"
              data-bs-toggle="modal" data-bs-target="#viewModal"
              data-item="<?php echo htmlspecialchars($row['item_name']); ?>"
              data-desc="<?php echo htmlspecialchars($row['description']); ?>"
              data-cat="<?php echo htmlspecialchars($row['category']); ?>"
              data-status="<?php echo htmlspecialchars($row['status']); ?>"
              data-reporter="<?php echo htmlspecialchars($row['name'] ?: 'Unknown'); ?>"
              data-contact="<?php echo htmlspecialchars($row['contact']); ?>"
              data-image="<?php echo $imgPath; ?>"
            >View</button>

            <?php if(isset($_SESSION['user_id']) && $_SESSION['user_id'] == $row['user_id']): ?>
              <a class="btn btn-outline-secondary btn-sm" href="edit_my_report.php?id=<?php echo $row['id']; ?>">Edit</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  </div>

  <!-- pagination -->
  <nav aria-label="Page navigation">
    <ul class="pagination justify-content-center">
      <li class="page-item <?php if($page <= 1) echo 'disabled'; ?>">
        <a class="page-link" href="?q=<?php echo urlencode($search); ?>&p=<?php echo $page - 1; ?>">Previous</a>
      </li>

      <?php
      $start = max(1, $page - 2);
      $end = min($totalPages, $page + 2);
      if($start > 1) {
        echo '<li class="page-item"><a class="page-link" href="?q='.urlencode($search).'&p=1">1</a></li>';
        if($start > 2) echo '<li class="page-item disabled"><span class="page-link">…</span></li>';
      }
      for($i = $start; $i <= $end; $i++): ?>
        <li class="page-item <?php if($i == $page) echo 'active'; ?>">
          <a class="page-link" href="?q=<?php echo urlencode($search); ?>&p=<?php echo $i; ?>"><?php echo $i; ?></a>
        </li>
      <?php endfor;
      if($end < $totalPages) {
        if($end < $totalPages - 1) echo '<li class="page-item disabled"><span class="page-link">…</span></li>';
        echo '<li class="page-item"><a class="page-link" href="?q='.urlencode($search).'&p='.$totalPages.'">'.$totalPages.'</a></li>';
      }
      ?>

      <li class="page-item <?php if($page >= $totalPages) echo 'disabled'; ?>">
        <a class="page-link" href="?q=<?php echo urlencode($search); ?>&p=<?php echo $page + 1; ?>">Next</a>
      </li>
    </ul>
  </nav>

  <?php endif; ?>

</div>

<!-- View modal -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="viewModalLabel">Report</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-md-6 d-flex align-items-center justify-content-center" id="modalImageWrap">
            <img id="modalImage" src="" alt="" class="img-fluid" style="max-height:320px; object-fit:cover; border-radius:12px;">
          </div>
          <div class="col-md-6">
            <h5 id="modalItem"></h5>
            <p class="text-muted mb-1">Category: <strong id="modalCat"></strong></p>
            <p class="text-muted mb-1">Status: <strong id="modalStatus"></strong></p>
            <p class="text-muted mb-1">Reporter: <span id="modalReporter"></span></p>
            <hr>
            <div id="modalDesc" class="small text-muted mb-2"></div>
            <div id="modalContact" class="small text-muted"></div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// populate modal from data- attributes
document.addEventListener('click', function(e){
  var btn = e.target.closest('.view-btn');
  if(!btn) return;
  var item = btn.getAttribute('data-item') || '';
  var desc = btn.getAttribute('data-desc') || '';
  var cat = btn.getAttribute('data-cat') || '';
  var status = btn.getAttribute('data-status') || '';
  var reporter = btn.getAttribute('data-reporter') || '';
  var contact = btn.getAttribute('data-contact') || '';
  var image = btn.getAttribute('data-image') || '';

  document.getElementById('modalItem').textContent = item;
  document.getElementById('modalDesc').textContent = desc;
  document.getElementById('modalCat').textContent = cat;
  document.getElementById('modalStatus').textContent = status.charAt(0).toUpperCase() + status.slice(1);
  document.getElementById('modalReporter').textContent = reporter;
  document.getElementById('modalContact').textContent = contact ? ('Contact: ' + contact) : '';
  var imgEl = document.getElementById('modalImage');
  if(image) {
    imgEl.src = image;
    imgEl.style.display = 'block';
  } else {
    imgEl.style.display = 'none';
  }
});
</script>
</body>
</html>