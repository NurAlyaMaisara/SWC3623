<?php
session_start();
include 'db_connect.php';

if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = intval($_SESSION['user_id']);

if(!isset($_GET['id'])) {
    header('Location: lostfound.php');
    exit;
}

$id = intval($_GET['id']);

// fetch report
$stmt = $conn->prepare("SELECT * FROM lostfound WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$report = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$report) {
    header('HTTP/1.1 404 Not Found');
    echo "Report not found.";
    exit;
}

// ensure current user owns this report
if(intval($report['user_id']) !== $user_id) {
    header('HTTP/1.1 403 Forbidden');
    echo "You don't have permission to edit this report.";
    exit;
}

$err = $ok = "";

// handle form submission
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_name = trim($_POST['item_name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $contact = trim($_POST['contact'] ?? '');
    $status = (isset($_POST['status']) && $_POST['status'] === 'found') ? 'found' : 'lost';
    $remove_image = isset($_POST['remove_image']) && $_POST['remove_image'] === '1';

    // validate
    if($item_name === '') $err = "Item name is required.";

    // handle image upload
    $newImage = null;
    if(isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $allowedTypes = ['image/jpeg','image/png','image/gif','image/webp'];
        if(!in_array($_FILES['image']['type'], $allowedTypes)) {
            $err = "Image type not allowed. Use JPG, PNG, WEBP or GIF.";
        } elseif(!getimagesize($_FILES['image']['tmp_name'])) {
            $err = "Uploaded file is not a valid image.";
        } else {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $newImage = uniqid('lf_') . '.' . $ext;
            $uploadDir = __DIR__ . '/uploads/';
            if(!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            if(!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $newImage)) {
                $err = "Failed to upload new image.";
                $newImage = null;
            }
        }
    }

    if(!$err) {
        // decide final image value
        $finalImage = $report['image']; // preserve by default
        if($remove_image) {
            if(!empty($report['image'])) {
                $old = __DIR__ . '/uploads/' . $report['image'];
                if(file_exists($old)) @unlink($old);
            }
            $finalImage = '';
        }
        if($newImage) {
            // remove old file
            if(!empty($report['image'])) {
                $old = __DIR__ . '/uploads/' . $report['image'];
                if(file_exists($old)) @unlink($old);
            }
            $finalImage = $newImage;
        }

        $stmt = $conn->prepare("UPDATE lostfound SET item_name=?, category=?, description=?, contact=?, status=?, image=? WHERE id=?");
        $stmt->bind_param("ssssssi", $item_name, $category, $description, $contact, $status, $finalImage, $id);
        if($stmt->execute()) {
            $ok = "Report updated.";
            $stmt->close();
            // refresh report data
            $stmt2 = $conn->prepare("SELECT * FROM lostfound WHERE id = ?");
            $stmt2->bind_param("i", $id);
            $stmt2->execute();
            $report = $stmt2->get_result()->fetch_assoc();
            $stmt2->close();
            // redirect back to lostfound list (optional anchor)
            header("Location: lostfound.php");
            exit;
        } else {
            $err = "Failed to update report.";
            $stmt->close();
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit Report | Lost & Found</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    .preview-img { max-height:260px; object-fit:cover; border-radius:10px; display:block; width:100%; }
    .upload-box { border:1px dashed rgba(0,0,0,0.08); padding:12px; border-radius:10px; text-align:center; cursor:pointer; }
  </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php"><img src="assets/images/P.png" alt="PeerSquare" style="height:40px;"></a>
    <div class="ms-auto">
      <a class="btn btn-outline-light btn-sm" href="lostfound.php">Back</a>
      <a class="btn btn-danger btn-sm" href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <div class="card p-3 col-md-8 offset-md-2">
    <h4>Edit Report</h4>

    <?php if($ok): ?><div class="alert alert-success"><?php echo htmlspecialchars($ok); ?></div><?php endif; ?>
    <?php if($err): ?><div class="alert alert-danger"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="row g-2">
        <div class="col-md-3">
          <label class="form-label">Status</label>
          <select name="status" class="form-control">
            <option value="lost" <?php if($report['status']=='lost') echo 'selected'; ?>>Lost</option>
            <option value="found" <?php if($report['status']=='found') echo 'selected'; ?>>Found</option>
          </select>
        </div>
        <div class="col-md-9">
          <label class="form-label">Item name</label>
          <input class="form-control" name="item_name" required value="<?php echo htmlspecialchars($report['item_name']); ?>">
        </div>
      </div>

      <div class="row g-2 mt-2">
        <div class="col-md-6">
          <label class="form-label">Category</label>
          <input class="form-control" name="category" value="<?php echo htmlspecialchars($report['category']); ?>">
        </div>
        <div class="col-md-6">
          <label class="form-label">Contact</label>
          <input class="form-control" name="contact" value="<?php echo htmlspecialchars($report['contact']); ?>">
        </div>
      </div>

      <div class="mt-2">
        <label class="form-label">Description</label>
        <textarea class="form-control" name="description" rows="4"><?php echo htmlspecialchars($report['description']); ?></textarea>
      </div>

      <div class="mt-3">
        <label class="form-label">Current image</label>
        <div class="mb-2">
          <?php if(!empty($report['image']) && file_exists(__DIR__ . '/uploads/' . $report['image'])): ?>
            <img src="uploads/<?php echo rawurlencode($report['image']); ?>" id="currentPreview" class="preview-img" alt="Current image">
            <div class="form-check mt-2">
              <input class="form-check-input" type="checkbox" id="removeImage" name="remove_image" value="1">
              <label class="form-check-label" for="removeImage">Remove current image</label>
            </div>
          <?php else: ?>
            <div class="upload-box" id="noPreviewBox">No image uploaded</div>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <label class="form-label">Replace / Upload image (optional)</label>
          <input class="form-control" type="file" name="image" id="imageInput" accept="image/*">
          <div class="mt-2 hint">Accepted: JPG, PNG, WEBP, GIF</div>
        </div>
      </div>

      <div class="d-flex gap-2">
        <button class="btn btn-primary">Save changes</button>
        <a class="btn btn-outline-secondary" href="lostfound.php">Cancel</a>
      </div>
    </form>
  </div>
</div>

<script>
(function(){
  const input = document.getElementById('imageInput');
  const currentPreview = document.getElementById('currentPreview');
  const noPreviewBox = document.getElementById('noPreviewBox');

  if(!input) return;
  input.addEventListener('change', function(){
    const f = this.files && this.files[0];
    if(!f){
      if(currentPreview) currentPreview.style.display = '';
      if(noPreviewBox) noPreviewBox.style.display = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = function(ev){
      if(currentPreview) {
        currentPreview.src = ev.target.result;
        currentPreview.style.display = 'block';
      } else if(noPreviewBox) {
        // create an img element if no current preview existed
        const img = document.createElement('img');
        img.className = 'preview-img';
        img.src = ev.target.result;
        noPreviewBox.replaceWith(img);
      }
      if(noPreviewBox) noPreviewBox.style.display = 'none';
    };
    reader.readAsDataURL(f);
  });
})();
</script>
</body>
</html>