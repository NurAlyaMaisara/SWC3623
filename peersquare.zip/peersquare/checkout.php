<?php
// checkout.php
// Preserves original site layout/styling while implementing "checkout selected items" behavior.
// Accepts selected cart_item ids (POST) from cart.php, validates ownership, shows summary,
// allows payment selection, creates order for only the chosen items and removes those cart rows.
session_start();
include 'db_connect.php';
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
$user_id = intval($_SESSION['user_id']);

// Collect selected cart IDs from POST (cart page)
$selected = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected']) && is_array($_POST['selected'])) {
    foreach ($_POST['selected'] as $c) $selected[] = intval($c);
} elseif (isset($_GET['selected']) && is_array($_GET['selected'])) {
    foreach ($_GET['selected'] as $c) $selected[] = intval($c);
}

if (empty($selected)) {
    header("Location: cart.php");
    exit;
}

// Protect: fetch only cart items belonging to this user and in the selected list
$placeholders = implode(',', array_fill(0, count($selected), '?'));
$sql = "SELECT ci.id AS cart_id, m.id AS listing_id, m.title, m.price, ci.quantity, m.image
        FROM cart_items ci JOIN marketplace m ON ci.listing_id = m.id
        WHERE ci.user_id = ? AND ci.id IN ($placeholders)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("DB error: " . $conn->error);
}

// bind params dynamically (mysqli requires references)
$types = 'i' . str_repeat('i', count($selected));
$params = [];
$params[] = &$user_id;
for ($i=0; $i<count($selected); $i++){
    $params[] = &$selected[$i];
}
call_user_func_array([$stmt, 'bind_param'], array_merge([$types], $params));
$stmt->execute();
$res = $stmt->get_result();

$order_items = [];
$total = 0.0;
while ($r = $res->fetch_assoc()) {
    $r['price'] = (float)$r['price'];
    $r['quantity'] = intval($r['quantity']);
    // If quantities were posted from cart adjustments, prefer those
    if (isset($_POST['qty']) && is_array($_POST['qty']) && isset($_POST['qty'][$r['cart_id']])) {
        $postedQ = intval($_POST['qty'][$r['cart_id']]);
        if ($postedQ > 0) {
            $r['quantity'] = $postedQ;
        }
    }
    $r['subtotal'] = $r['price'] * $r['quantity'];
    $total += $r['subtotal'];
    $order_items[] = $r;
}
$stmt->close();

if (empty($order_items)) {
    header("Location: cart.php");
    exit;
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $payment_method = trim($_POST['payment_method'] ?? 'cod');

    // Decide order status:
    // online -> completed (simulate immediate payment)
    // cod/manual -> pending_payment
    $status = ($payment_method === 'online') ? 'completed' : 'pending_payment';

    $conn->begin_transaction();
    try {
        $o = $conn->prepare("INSERT INTO orders (user_id, total_amount, status, payment_method, created_at) VALUES (?, ?, ?, ?, NOW())");
        if (!$o) throw new Exception("Prepare orders failed: " . $conn->error);
        $o->bind_param("idss", $user_id, $total, $status, $payment_method);
        if (!$o->execute()) throw new Exception("Create order failed: " . $o->error);
        $order_id = $o->insert_id;
        $o->close();

        // insert order_items for the selected cart items
        foreach ($order_items as $it) {
            $ins = $conn->prepare("INSERT INTO order_items (order_id, listing_id, title, price, quantity, subtotal) VALUES (?, ?, ?, ?, ?, ?)");
            if (!$ins) throw new Exception("Prepare order_items failed: " . $conn->error);
            $ins->bind_param("iisdid", $order_id, $it['listing_id'], $it['title'], $it['price'], $it['quantity'], $it['subtotal']);
            if (!$ins->execute()) throw new Exception("Insert order_item failed: " . $ins->error);
            $ins->close();
        }

        // remove only the selected cart_items that belonged to user
        $del_placeholders = implode(',', array_fill(0, count($selected), '?'));
        $del_sql = "DELETE FROM cart_items WHERE user_id = ? AND id IN ($del_placeholders)";
        $del = $conn->prepare($del_sql);
        if (!$del) throw new Exception("Prepare delete cart_items failed: " . $conn->error);

        $del_types = 'i' . str_repeat('i', count($selected));
        $del_params = [];
        $del_params[] = &$user_id;
        for ($i=0;$i<count($selected);$i++) $del_params[] = &$selected[$i];
        call_user_func_array([$del, 'bind_param'], array_merge([$del_types], $del_params));
        $del->execute();
        $del->close();

        $conn->commit();
        header("Location: order_success.php?id=" . intval($order_id));
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        $err = "Failed to place order: " . $e->getMessage();
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Checkout — PeerSquare</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <style>.muted-small{color:#666;font-size:0.95rem}</style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php"><img src="assets/images/P.png" alt="PeerSquare" style="height:38px;"></a>
    <div class="ms-auto">
      <a class="btn btn-outline-light btn-sm" href="cart.php">Back to cart</a>
      <a class="btn btn-danger btn-sm" href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <h3>Checkout — Selected items</h3>
  <?php if($err): ?><div class="alert alert-danger"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

  <div class="card mb-3">
    <div class="card-body">
      <h5>Items to purchase</h5>
      <?php foreach($order_items as $it): ?>
        <div class="d-flex justify-content-between py-2 border-bottom">
          <div>
            <strong><?php echo htmlspecialchars($it['title']); ?></strong>
            <div class="muted-small">Qty: <?php echo intval($it['quantity']); ?></div>
          </div>
          <div>RM <?php echo number_format($it['subtotal'],2); ?></div>
        </div>
      <?php endforeach; ?>
      <div class="d-flex justify-content-between pt-3">
        <div class="muted-small"><strong>Total</strong></div>
        <div style="font-weight:700;">RM <?php echo number_format($total,2); ?></div>
      </div>
    </div>
  </div>

  <form method="post" class="card p-3">
    <input type="hidden" name="place_order" value="1">
    <?php foreach($selected as $s): ?>
      <input type="hidden" name="selected[]" value="<?php echo intval($s); ?>">
    <?php endforeach; ?>

    <div class="mb-3">
      <label class="form-label">Payment method</label>
      <select name="payment_method" class="form-select">
        <option value="cod">Cash on delivery (COD)</option>
        <option value="online">Online</option>
      </select>
    </div>

    <div class="d-flex gap-2">
      <button class="btn btn-primary" type="submit">Place order</button>
      <a class="btn btn-outline-secondary ms-auto" href="cart.php">Back to cart</a>
    </div>
  </form>
</div>
</body>
</html>