<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='admin'){ header("Location: login.php"); exit; }
include '../db_connect.php';

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['id'])){
    $id = intval($_POST['id']);
    $action = $_POST['action']; // 'approve', 'reject', or 'delete'
    if($action === 'approve'){
        $stmt = $conn->prepare("UPDATE marketplace SET status='approved' WHERE id=?");
        $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
    } elseif($action === 'reject'){
        $stmt = $conn->prepare("UPDATE marketplace SET status='rejected' WHERE id=?");
        $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
    } elseif($action === 'delete'){
        $img = $conn->query("SELECT image FROM marketplace WHERE id=$id")->fetch_assoc()['image'];
        if($img && file_exists(__DIR__ . "/../uploads/".$img)) unlink(__DIR__ . "/../uploads/".$img);
        $stmt = $conn->prepare("DELETE FROM marketplace WHERE id=?");
        $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
    }
    header("Location: manage_marketplace.php"); exit;
}

$res = $conn->query("SELECT m.*, u.name FROM marketplace m LEFT JOIN users u ON m.user_id=u.id ORDER BY m.created_at DESC");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Manage Marketplace</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="admin_style.css">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h4 class="mb-4">Marketplace Posts</h4>

  <div class="row">
    <?php while($r = $res->fetch_assoc()): ?>
    <div class="col-md-4">
      <div class="card mb-3 fade-in">
        <?php if($r['image'] && file_exists(__DIR__ . "/../uploads/".$r['image'])): ?>
        <img src="../uploads/<?php echo $r['image']; ?>" class="card-img-top product" alt="Product Image">
        <?php endif; ?>
        <div class="card-body">
          <h5 class="card-title"><?php echo htmlspecialchars($r['title']); ?> <span class="badge <?php echo $r['status']=='approved'?'bg-success':($r['status']=='rejected'?'bg-danger':'bg-secondary'); ?>"><?php echo $r['status']; ?></span></h5>
          <p class="card-text mb-1"><strong>Seller:</strong> <?php echo htmlspecialchars($r['name']); ?></p>
          <p class="card-text mb-2"><strong>Price:</strong> RM <?php echo number_format($r['price'],2); ?></p>
          <form method="post" class="d-grid gap-1">
            <input type="hidden" name="id" value="<?php echo $r['id']; ?>">
            <?php if($r['status']!=='approved'): ?>
              <button name="action" value="approve" class="btn btn-success btn-sm w-100">Approve</button>
            <?php endif; ?>
            <?php if($r['status']!=='rejected'): ?>
              <button name="action" value="reject" class="btn btn-warning btn-sm w-100">Reject</button>
            <?php endif; ?>
            <button name="action" value="delete" onclick="return confirm('Delete this post?')" class="btn btn-danger btn-sm w-100">Delete</button>
          </form>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
  </div>

</div>
</body>
</html>
