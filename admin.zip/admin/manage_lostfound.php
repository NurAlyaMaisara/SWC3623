<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='admin'){ header("Location: login.php"); exit; }
include '../db_connect.php';
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['delete_id'])){
  $id = intval($_POST['delete_id']);
  $stmt = $conn->prepare("DELETE FROM lostfound WHERE id=?");
  $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
  header("Location: manage_lostfound.php"); exit;
}
$res = $conn->query("SELECT l.*, u.name FROM lostfound l LEFT JOIN users u ON l.user_id=u.id ORDER BY l.created_at DESC");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Manage Lost/Found</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="admin_style.css">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h4 class="mb-4">Lost & Found Reports</h4>

  <div class="row">
    <?php while($r = $res->fetch_assoc()): ?>
    <div class="col-md-6">
      <div class="card mb-3 fade-in">
        <div class="card-body">
          <h5 class="card-title"><?php echo htmlspecialchars($r['item_name']); ?> <span class="badge bg-info"><?php echo $r['status']; ?></span></h5>
          <p class="card-text mb-1"><strong>Reporter:</strong> <?php echo htmlspecialchars($r['name']); ?></p>
          <p class="card-text mb-1"><strong>Contact:</strong> <?php echo htmlspecialchars($r['contact']); ?></p>
          <form method="post" onsubmit="return confirm('Delete this report?')">
            <input type="hidden" name="delete_id" value="<?php echo $r['id']; ?>">
            <button class="btn btn-danger btn-sm w-100">Delete</button>
          </form>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
  </div>
</div>
</body>
</html>
