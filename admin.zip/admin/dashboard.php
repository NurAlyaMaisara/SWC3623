<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin'){
  header("Location: login.php");
  exit;
}
include '../db_connect.php';

// gather stats
$totUsers = $conn->query("SELECT COUNT(*) AS c FROM users")->fetch_assoc()['c'];
$totMarket = $conn->query("SELECT COUNT(*) AS c FROM marketplace")->fetch_assoc()['c'];
$pending = $conn->query("SELECT COUNT(*) AS c FROM marketplace WHERE status='pending'")->fetch_assoc()['c'];
$lostCount = $conn->query("SELECT COUNT(*) AS c FROM lostfound")->fetch_assoc()['c'];
?>

<!doctype html><html><head><meta charset="utf-8"><title>Admin Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<link href="assets/css/style.css" rel="stylesheet">
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark"><div class="container">
  <a class="navbar-brand" href="#">PeerSquare Admin</a>
  <div class="ms-auto">
    <a class="btn btn-outline-light btn-sm" href="../index.php">Site</a>
    <a class="btn btn-danger btn-sm" href="../logout.php">Logout</a>
  </div>
</div></nav>

<div class="container mt-4">
  <h3>Admin Dashboard</h3>
  <div class="row">
    <div class="col-md-3"><div class="card p-3"><h6>Users</h6><h4><?php echo $totUsers; ?></h4></div></div>
    <div class="col-md-3"><div class="card p-3"><h6>Marketplace</h6><h4><?php echo $totMarket; ?></h4></div></div>
    <div class="col-md-3"><div class="card p-3"><h6>Pending</h6><h4><?php echo $pending; ?></h4></div></div>
    <div class="col-md-3"><div class="card p-3"><h6>Lost & Found</h6><h4><?php echo $lostCount; ?></h4></div></div>
  </div>

  <div class="mt-4">
    <a href="manage_users.php" class="btn btn-outline-primary">Manage Users</a>
    <a href="manage_marketplace.php" class="btn btn-outline-primary">Manage Marketplace</a>
    <a href="manage_lostfound.php" class="btn btn-outline-primary">Manage Lost/Found</a>
  </div>
</div>
</body></html>
