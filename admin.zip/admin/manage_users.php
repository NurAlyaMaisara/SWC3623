<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role']!=='admin'){ header("Location: login.php"); exit; }
include '../db_connect.php';
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['delete_id'])){
  $id = intval($_POST['delete_id']);
  $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
  $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
  header("Location: manage_users.php"); exit;
}
$res = $conn->query("SELECT id,name,email,role,created_at FROM users ORDER BY created_at DESC");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Manage Users</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="admin_style.css"> <!-- Link your improved CSS -->
</head>
<body class="bg-light">
<div class="container mt-4">
  <h4 class="mb-4">Users</h4>

  <div class="row">
    <?php while($u = $res->fetch_assoc()): ?>
    <div class="col-md-4">
      <div class="card fade-in">
        <div class="card-body">
          <h5 class="card-title"><?php echo htmlspecialchars($u['name']); ?></h5>
          <p class="card-text mb-1"><strong>Email:</strong> <?php echo htmlspecialchars($u['email']); ?></p>
          <p class="card-text mb-3"><strong>Role:</strong> <?php echo $u['role']; ?></p>
          <form method="post" onsubmit="return confirm('Delete user?')">
            <input type="hidden" name="delete_id" value="<?php echo $u['id']; ?>">
            <button class="btn btn-danger btn-sm w-100">Delete</button>
          </form>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
  </div>

</div>
</body>
</html>
